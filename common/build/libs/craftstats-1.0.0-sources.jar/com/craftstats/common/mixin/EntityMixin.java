package com.craftstats.common.mixin;

import com.craftstats.common.stats.MobStats;
import com.craftstats.common.stats.PlayerStats;
import com.craftstats.common.stats.StatRegistry;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public abstract class EntityMixin {

    @Inject(method = "isOnFire", at = @At("HEAD"), cancellable = true)
    private void craftstats$fireImmune(CallbackInfoReturnable<Boolean> cir) {
        class_1297 self = (class_1297) (Object) this;
        if (!(self instanceof class_1309)) return;
        if (self instanceof class_1657 player) {
            PlayerStats ps = StatRegistry.getPlayer(player.method_5667());
            if (ps != null && ps.fireImmune) cir.setReturnValue(false);
            return;
        }
        class_1309 living = (class_1309) self;
        class_2960 typeId = class_1299.method_5890(living.method_5864());
        if (typeId == null) return;
        MobStats stats = StatRegistry.getMob(typeId);
        if (stats != null && stats.immuneFire) cir.setReturnValue(false);
    }
}
