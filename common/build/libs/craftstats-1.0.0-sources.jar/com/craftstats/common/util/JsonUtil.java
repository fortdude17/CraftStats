package com.craftstats.common.util;

import com.craftstats.common.stats.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.minecraft.class_1309;
import net.minecraft.class_1324;
import net.minecraft.class_5134;

public final class JsonUtil {

    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static final Gson GSON_COMPACT = new GsonBuilder().create();

    private JsonUtil() {}

    public static String serializeMobStats(class_1309 entity) {
        MobStats stats = new MobStats();
        stats.maxHealth = entity.method_6063();
        var attrDamage = entity.method_5996(class_5134.field_23721);
        if (attrDamage != null) stats.attackDamage = attrDamage.method_6194();
        var attrArmor = entity.method_5996(class_5134.field_23724);
        if (attrArmor != null) stats.armor = attrArmor.method_6194();
        var attrSpeed = entity.method_5996(class_5134.field_23719);
        if (attrSpeed != null) stats.moveSpeed = attrSpeed.method_6194();

        JsonObject root = new JsonObject();
        root.addProperty("type", "mob");
        root.addProperty("entity_type", entity.method_5864().toString());
        root.add("stats", GSON.toJsonTree(stats));
        return GSON.toJson(root);
    }

    public static String toJson(Object obj) {
        return GSON.toJson(obj);
    }

    public static String toCompactJson(Object obj) {
        return GSON_COMPACT.toJson(obj);
    }

    public static <T> T fromJson(String json, Class<T> clazz) {
        return GSON.fromJson(json, clazz);
    }

    public static MobStats mobStatsFromJson(String json) {
        return GSON.fromJson(json, MobStats.class);
    }

    public static BlockStats blockStatsFromJson(String json) {
        return GSON.fromJson(json, BlockStats.class);
    }

    public static ItemStats itemStatsFromJson(String json) {
        return GSON.fromJson(json, ItemStats.class);
    }

    public static PlayerStats playerStatsFromJson(String json) {
        return GSON.fromJson(json, PlayerStats.class);
    }
}
