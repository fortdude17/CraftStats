package com.craftstats.common.registry;

import com.craftstats.common.CraftStats;
import com.craftstats.common.item.ModItems;
import dev.architectury.registry.CreativeTabRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1761;
import net.minecraft.class_2561;
import net.minecraft.class_7924;

public final class ModCreativeTab {

    public static final DeferredRegister<class_1761> TABS =
            DeferredRegister.create(CraftStats.MOD_ID, class_7924.field_44688);

    public static final RegistrySupplier<class_1761> CRAFTSTATS_TAB = TABS.register(
            "craftstats", () -> CreativeTabRegistry.create(
                    class_2561.method_43471("itemGroup.craftstats"),
                    () -> ModItems.CRAFT_WAND.get().method_7854()
            )
    );

    public static void register() {
        TABS.register();
        CreativeTabRegistry.modify(CRAFTSTATS_TAB, (flags, output, canSeeOp) -> {
            output.method_45421(ModItems.CRAFT_WAND.get());
            output.method_45421(ModItems.PLAYER_STATS_BOOK.get());
        });
    }
}
