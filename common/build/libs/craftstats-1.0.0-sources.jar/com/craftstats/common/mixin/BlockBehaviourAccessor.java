package com.craftstats.common.mixin;

import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4970.class)
public interface BlockBehaviourAccessor {
    @Accessor("properties")
    class_4970.class_2251 craftstats$getBlockProperties();
}
