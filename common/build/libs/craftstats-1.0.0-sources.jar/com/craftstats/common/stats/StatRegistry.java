package com.craftstats.common.stats;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public final class StatRegistry {

    private static final Map<class_2960, MobStats>    MOB_OVERRIDES       = new ConcurrentHashMap<>();
    private static final Map<class_2960, BlockStats>   BLOCK_OVERRIDES     = new ConcurrentHashMap<>();
    private static final Map<class_2960, ItemStats>    ITEM_OVERRIDES      = new ConcurrentHashMap<>();
    private static final Map<UUID,             PlayerStats>  PLAYER_OVERRIDES    = new ConcurrentHashMap<>();

    private static final Map<UUID,             MobStats>     MOB_UUID_OVERRIDES  = new ConcurrentHashMap<>();

    private static final Map<String,           BlockStats>   BLOCK_POS_OVERRIDES = new ConcurrentHashMap<>();

    public static void init() {
        MOB_OVERRIDES.clear();
        BLOCK_OVERRIDES.clear();
        ITEM_OVERRIDES.clear();
        PLAYER_OVERRIDES.clear();
        MOB_UUID_OVERRIDES.clear();
        BLOCK_POS_OVERRIDES.clear();
    }

    public static String makePosKey(class_5321<class_1937> dim, class_2338 pos) {
        return dim.method_29177() + "|" + pos.method_10263() + "|" + pos.method_10264() + "|" + pos.method_10260();
    }

    public static void setMob(class_2960 type, MobStats stats)  { MOB_OVERRIDES.put(type, stats); }
    public static MobStats getMob(class_2960 type)               { return MOB_OVERRIDES.get(type); }
    public static void removeMob(class_2960 type)                { MOB_OVERRIDES.remove(type); }
    public static Map<class_2960, MobStats> allMobs()            { return MOB_OVERRIDES; }

    public static void setBlock(class_2960 id, BlockStats s)     { BLOCK_OVERRIDES.put(id, s); }
    public static BlockStats getBlock(class_2960 id)             { return BLOCK_OVERRIDES.get(id); }
    public static void removeBlock(class_2960 id)                { BLOCK_OVERRIDES.remove(id); }
    public static Map<class_2960, BlockStats> allBlocks()        { return BLOCK_OVERRIDES; }

    public static void setItem(class_2960 id, ItemStats s)       { ITEM_OVERRIDES.put(id, s); }
    public static ItemStats getItem(class_2960 id)               { return ITEM_OVERRIDES.get(id); }
    public static void removeItem(class_2960 id)                 { ITEM_OVERRIDES.remove(id); }
    public static Map<class_2960, ItemStats> allItems()          { return ITEM_OVERRIDES; }

    public static void setPlayer(UUID uuid, PlayerStats s)             { PLAYER_OVERRIDES.put(uuid, s); }
    public static PlayerStats getPlayer(UUID uuid)                     { return PLAYER_OVERRIDES.get(uuid); }
    public static void removePlayer(UUID uuid)                         { PLAYER_OVERRIDES.remove(uuid); }
    public static Map<UUID, PlayerStats> allPlayers()                  { return PLAYER_OVERRIDES; }

    public static void setMobUuid(UUID uuid, MobStats stats)  { MOB_UUID_OVERRIDES.put(uuid, stats); }
    public static MobStats getMobUuid(UUID uuid)               { return MOB_UUID_OVERRIDES.get(uuid); }
    public static void removeMobUuid(UUID uuid)                { MOB_UUID_OVERRIDES.remove(uuid); }
    public static Map<UUID, MobStats> allMobUuids()            { return MOB_UUID_OVERRIDES; }

    public static void setBlockAt(String posKey, BlockStats s)         { BLOCK_POS_OVERRIDES.put(posKey, s); }
    public static BlockStats getBlockAt(String posKey)                 { return BLOCK_POS_OVERRIDES.get(posKey); }
    public static void removeBlockAt(String posKey)                    { BLOCK_POS_OVERRIDES.remove(posKey); }
    public static Map<String, BlockStats> allBlockPositions()          { return BLOCK_POS_OVERRIDES; }
}
