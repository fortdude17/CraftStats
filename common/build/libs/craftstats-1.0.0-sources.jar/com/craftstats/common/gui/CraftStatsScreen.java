package com.craftstats.common.gui;

import com.craftstats.common.gui.panel.EntityBrowserPanel;
import com.craftstats.common.gui.panel.StatEditorPanel;
import com.craftstats.common.gui.widget.FooterBar;
import com.craftstats.common.network.CraftStatsNetwork;
import com.craftstats.common.stats.*;
import java.util.UUID;
import net.minecraft.class_1309;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class CraftStatsScreen extends class_437 {

    private static final int PANEL_LEFT_W = 200;
    private static final int FOOTER_H     = 24;
    private static final int PADDING      = 4;

    private TargetType activeType     = TargetType.MOB;
    private String     targetId       = "";
    private Object     workingStats;
    private Object     vanillaStats;
    private int        unsavedChanges = 0;

    private UUID       mobInstanceUuid = null;

    private EntityBrowserPanel browserPanel;
    private StatEditorPanel    editorPanel;
    private FooterBar          footerBar;

    private final class_1309 preselectedMob;
    private final class_2248        preselectedBlock;
    private final TargetType   preselectedType;
    private final String       preselectedId;

    public CraftStatsScreen(class_1309 mob) {
        super(class_2561.method_43470("CraftStats"));
        this.preselectedMob   = mob;
        this.preselectedBlock = null;
        this.preselectedType  = TargetType.MOB;
        this.preselectedId    = null;
        this.activeType       = TargetType.MOB;
    }

    public CraftStatsScreen(class_2248 block) {
        super(class_2561.method_43470("CraftStats"));
        this.preselectedMob   = null;
        this.preselectedBlock = block;
        this.preselectedType  = TargetType.BLOCK;
        this.preselectedId    = null;
        this.activeType       = TargetType.BLOCK;
    }

    public CraftStatsScreen(TargetType type, String id) {
        super(class_2561.method_43470("CraftStats"));
        this.preselectedMob   = null;
        this.preselectedBlock = null;
        this.preselectedType  = type;
        this.preselectedId    = id;
        this.activeType       = type;
    }

    public CraftStatsScreen() {
        super(class_2561.method_43470("CraftStats"));
        this.preselectedMob   = null;
        this.preselectedBlock = null;
        this.preselectedType  = null;
        this.preselectedId    = null;
    }

    @Override
    protected void method_25426() {
        int leftW  = PANEL_LEFT_W;
        int rightX = leftW + PADDING * 2;
        int rightW = this.field_22789 - rightX - PADDING;
        int bodyH  = this.field_22790 - FOOTER_H - PADDING * 3;

        browserPanel = new EntityBrowserPanel(this, PADDING, PADDING, leftW, bodyH);
        editorPanel  = new StatEditorPanel(this, rightX, PADDING, rightW, bodyH);
        footerBar    = new FooterBar(this, PADDING, this.field_22790 - FOOTER_H - PADDING,
                this.field_22789 - PADDING * 2, FOOTER_H);

        browserPanel.init();
        editorPanel.init();
        footerBar.init();

        if (preselectedMob != null) {
            selectMob(preselectedMob);
        } else if (preselectedBlock != null) {
            selectBlock(preselectedBlock);
        } else if (preselectedType != null && preselectedId != null) {
            switch (preselectedType) {
                case MOB    -> selectMobById(preselectedId);
                case BLOCK  -> selectBlockById(preselectedId);
                case ITEM   -> selectItemById(preselectedId);
                default     -> {}
            }
        } else if (workingStats != null && !targetId.isEmpty()) {

            editorPanel.loadTarget(activeType, targetId, workingStats);
            editorPanel.setInstanceMode(activeType == TargetType.MOB && mobInstanceUuid != null);
            footerBar.update(unsavedChanges);
            browserPanel.setSelectedAndScroll(targetId);
        }
    }

    @Override
    public void method_25420(class_332 g, int mouseX, int mouseY, float delta) {

    }

    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float delta) {

        g.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF0D0D1C);

        int bodyH = this.field_22790 - FOOTER_H - PADDING * 3;

        g.method_25294(PADDING,                 PADDING, PADDING + PANEL_LEFT_W,  PADDING + bodyH, 0xFF1A1A2E);
        g.method_25294(PANEL_LEFT_W + PADDING * 2, PADDING, this.field_22789 - PADDING,  PADDING + bodyH, 0xFF16213E);
        g.method_25294(PADDING, this.field_22790 - FOOTER_H - PADDING,
               this.field_22789 - PADDING, this.field_22790 - PADDING, 0xFF0F3460);

        drawBorder(g, PADDING, PADDING,
                PADDING + PANEL_LEFT_W, PADDING + bodyH, 0xFF3355AA);
        drawBorder(g, PANEL_LEFT_W + PADDING * 2, PADDING,
                this.field_22789 - PADDING, PADDING + bodyH, 0xFF3355AA);
        drawBorder(g, PADDING, this.field_22790 - FOOTER_H - PADDING,
                this.field_22789 - PADDING, this.field_22790 - PADDING, 0xFF3355AA);

        browserPanel.render(g, mouseX, mouseY, delta);
        editorPanel.render(g, mouseX, mouseY, delta);
        footerBar.render(g, mouseX, mouseY, delta);

        super.method_25394(g, mouseX, mouseY, delta);
    }

    private static void drawBorder(class_332 g, int x1, int y1, int x2, int y2, int color) {
        g.method_25294(x1,     y1,     x2,     y1 + 1, color);
        g.method_25294(x1,     y2 - 1, x2,     y2,     color);
        g.method_25294(x1,     y1,     x1 + 1, y2,     color);
        g.method_25294(x2 - 1, y1,     x2,     y2,     color);
    }

    @Override
    public boolean method_25402(double x, double y, int btn) {

        browserPanel.clearSearchFocus();
        editorPanel.clearAllFocus();
        if (browserPanel.mouseClicked(x, y, btn)) return true;
        if (editorPanel.mouseClicked(x, y, btn))  return true;
        if (footerBar.mouseClicked(x, y, btn))    return true;
        return super.method_25402(x, y, btn);
    }

    @Override
    public boolean method_25401(double x, double y, double hScroll, double vScroll) {
        if (browserPanel.mouseScrolled(x, y, hScroll, vScroll)) return true;
        if (editorPanel.mouseScrolled(x, y, hScroll, vScroll))  return true;
        return super.method_25401(x, y, hScroll, vScroll);
    }

    @Override
    public boolean method_25404(int key, int scan, int mods) {
        if (browserPanel.keyPressed(key, scan, mods)) return true;
        if (editorPanel.keyPressed(key, scan, mods))  return true;
        return super.method_25404(key, scan, mods);
    }

    @Override
    public boolean method_25400(char c, int mods) {
        if (browserPanel.charTyped(c, mods)) return true;
        if (editorPanel.charTyped(c, mods))  return true;
        return super.method_25400(c, mods);
    }

    public void selectMob(class_1309 entity) {
        activeType      = TargetType.MOB;
        mobInstanceUuid = entity.method_5667();
        targetId        = net.minecraft.class_1299.method_5890(entity.method_5864()).toString();

        MobStats existing = StatRegistry.getMobUuid(entity.method_5667());
        vanillaStats   = existing != null ? existing.copy() : new MobStats();
        workingStats   = ((MobStats) vanillaStats).copy();
        unsavedChanges = 0;
        editorPanel.loadTarget(activeType, targetId, workingStats);
        editorPanel.setInstanceMode(true);
        footerBar.update(unsavedChanges);
        if (browserPanel != null) browserPanel.setSelectedAndScroll(targetId);
    }

    public void selectBlock(class_2248 block) {
        activeType = TargetType.BLOCK;
        targetId   = net.minecraft.class_7923.field_41175.method_10221(block).toString();
        BlockStats existing = StatRegistry.getBlock(class_2960.method_60654(targetId));
        vanillaStats   = existing != null ? existing.copy() : new BlockStats();
        workingStats   = ((BlockStats) vanillaStats).copy();
        unsavedChanges = 0;
        editorPanel.loadTarget(activeType, targetId, workingStats);
        footerBar.update(unsavedChanges);
        if (browserPanel != null) browserPanel.setSelectedAndScroll(targetId);
    }

    public void selectMobById(String typeId) {
        activeType      = TargetType.MOB;
        mobInstanceUuid = null;
        targetId        = typeId;
        MobStats existing = StatRegistry.getMob(class_2960.method_60654(targetId));
        vanillaStats   = existing != null ? existing.copy() : new MobStats();
        workingStats   = ((MobStats) vanillaStats).copy();
        unsavedChanges = 0;
        editorPanel.loadTarget(activeType, targetId, workingStats);
        editorPanel.setInstanceMode(false);
        footerBar.update(unsavedChanges);
        if (browserPanel != null) browserPanel.setSelectedAndScroll(targetId);
    }

    public void selectBlockById(String blockId) {
        activeType = TargetType.BLOCK;
        targetId   = blockId;
        BlockStats existing = StatRegistry.getBlock(class_2960.method_60654(targetId));
        vanillaStats   = existing != null ? existing.copy() : new BlockStats();
        workingStats   = ((BlockStats) vanillaStats).copy();
        unsavedChanges = 0;
        editorPanel.loadTarget(activeType, targetId, workingStats);
        footerBar.update(unsavedChanges);
        if (browserPanel != null) browserPanel.setSelectedAndScroll(targetId);
    }

    public void selectItemById(String itemId) {
        activeType = TargetType.ITEM;
        targetId   = itemId;
        ItemStats existing = StatRegistry.getItem(class_2960.method_60654(targetId));
        vanillaStats   = existing != null ? existing.copy() : new ItemStats();
        workingStats   = ((ItemStats) vanillaStats).copy();
        unsavedChanges = 0;
        editorPanel.loadTarget(activeType, targetId, workingStats);
        footerBar.update(unsavedChanges);
        if (browserPanel != null) browserPanel.setSelectedAndScroll(targetId);
    }

    public void selectPlayerById(UUID uuid, String displayName) {
        activeType = TargetType.PLAYER;
        targetId   = uuid.toString();
        PlayerStats existing = StatRegistry.getPlayer(uuid);
        vanillaStats   = existing != null ? existing.copy() : new PlayerStats();
        workingStats   = ((PlayerStats) vanillaStats).copy();
        unsavedChanges = 0;
        editorPanel.loadTarget(activeType, targetId, workingStats);
        footerBar.update(unsavedChanges);
        if (browserPanel != null) browserPanel.setSelectedAndScroll(targetId);
    }

    public void onApply() {
        if (targetId.isEmpty()) return;
        switch (activeType) {
            case MOB -> {
                if (mobInstanceUuid != null)
                    CraftStatsNetwork.sendApplyMobUuidStats(mobInstanceUuid, (MobStats) workingStats);
                else
                    CraftStatsNetwork.sendApplyMobStats(targetId, (MobStats) workingStats);
            }
            case BLOCK  -> CraftStatsNetwork.sendApplyBlockStats(targetId, (BlockStats) workingStats);
            case ITEM   -> CraftStatsNetwork.sendApplyItemStats(targetId, (ItemStats) workingStats);
            case PLAYER -> CraftStatsNetwork.sendApplyPlayerStats(
                    UUID.fromString(targetId), (PlayerStats) workingStats);
        }
        unsavedChanges = 0;
        footerBar.update(0);
    }

    public void onReset() {
        if (targetId.isEmpty()) return;
        switch (activeType) {
            case MOB -> {
                if (mobInstanceUuid != null) CraftStatsNetwork.sendResetMobUuid(mobInstanceUuid);
                else CraftStatsNetwork.sendReset("mob", targetId);
                workingStats = new MobStats(); vanillaStats = new MobStats();
            }
            case BLOCK  -> { CraftStatsNetwork.sendReset("block",  targetId); workingStats = new BlockStats();  vanillaStats = new BlockStats(); }
            case ITEM   -> { CraftStatsNetwork.sendReset("item",   targetId); workingStats = new ItemStats();   vanillaStats = new ItemStats(); }
            case PLAYER -> { CraftStatsNetwork.sendReset("player", targetId); workingStats = new PlayerStats(); vanillaStats = new PlayerStats(); }
        }
        editorPanel.loadTarget(activeType, targetId, workingStats);
        unsavedChanges = 0;
        footerBar.update(0);
    }

    public void onResetAll() {
        com.craftstats.common.network.CraftStatsNetwork.sendResetAll();

        workingStats   = null;
        vanillaStats   = null;
        targetId       = "";
        activeType     = TargetType.MOB;
        unsavedChanges = 0;
        footerBar.update(0);

        browserPanel.init();
        editorPanel.loadTarget(null, "", null);
    }

    public void onCopyProfile() {
        if (workingStats == null) return;
        String json = com.craftstats.common.util.JsonUtil.toJson(workingStats);
        net.minecraft.class_310.method_1551().field_1774.method_1455(json);
    }

    public void onPasteProfile() {
        String clip = net.minecraft.class_310.method_1551().field_1774.method_1460();
        if (clip == null || clip.isEmpty()) return;
        try {
            switch (activeType) {
                case MOB    -> workingStats = com.craftstats.common.util.JsonUtil.mobStatsFromJson(clip);
                case BLOCK  -> workingStats = com.craftstats.common.util.JsonUtil.blockStatsFromJson(clip);
                case ITEM   -> workingStats = com.craftstats.common.util.JsonUtil.itemStatsFromJson(clip);
                case PLAYER -> workingStats = com.craftstats.common.util.JsonUtil.playerStatsFromJson(clip);
            }
            editorPanel.loadTarget(activeType, targetId, workingStats);
            markDirty();
        } catch (Exception ignored) {}
    }

    public void markDirty() {
        unsavedChanges++;
        footerBar.update(unsavedChanges);
    }

    public TargetType getActiveType()   { return activeType; }
    public String     getTargetId()     { return targetId; }
    public Object     getWorkingStats() { return workingStats; }
    public Object     getVanillaStats() { return vanillaStats; }
    public int        getUnsaved()      { return unsavedChanges; }

    @Override
    public void method_25393() {
        if (footerBar != null) footerBar.tick();
    }

    @Override
    public boolean method_25421() { return false; }
}
