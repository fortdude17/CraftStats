package com.craftstats.common.item;

import com.craftstats.common.stats.PlayerStats;
import com.craftstats.common.stats.StatRegistry;
import com.craftstats.common.util.ScreenOpener;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class PlayerStatsBookItem extends class_1792 {

    public PlayerStatsBookItem(class_1793 props) {
        super(props);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (level.field_9236) {
            ScreenOpener.openPlayerEditor(player);
        }
        return class_1271.method_29237(player.method_5998(hand), level.field_9236);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 ctx,
                                 List<class_2561> lines, class_1836 flag) {
        lines.add(class_2561.method_43470("Right-click to edit your stats").method_27692(class_124.field_1080));
        lines.add(class_2561.method_43473());

        try {
            net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
            if (mc.field_1724 != null) {
                PlayerStats ps = StatRegistry.getPlayer(mc.field_1724.method_5667());
                if (ps != null) {
                    lines.add(class_2561.method_43470("Current overrides:").method_27692(class_124.field_1054));
                    lines.add(class_2561.method_43470("  HP: " + ps.maxHealth
                            + "  Dmg: " + ps.baseDamage
                            + "  Speed: " + ps.walkSpeed)
                            .method_27692(class_124.field_1068));
                    if (ps.godMode)        lines.add(class_2561.method_43470("  ★ God Mode").method_27692(class_124.field_1065));
                    if (ps.noFallDamage)   lines.add(class_2561.method_43470("  ★ No Fall Damage").method_27692(class_124.field_1075));
                    if (ps.keepInventory)  lines.add(class_2561.method_43470("  ★ Keep Inventory").method_27692(class_124.field_1060));
                    if (ps.fireImmune)     lines.add(class_2561.method_43470("  ★ Fire Immune").method_27692(class_124.field_1061));
                    if (ps.infiniteItems)  lines.add(class_2561.method_43470("  ★ Infinite Items").method_27692(class_124.field_1076));
                } else {
                    lines.add(class_2561.method_43470("No active overrides — vanilla stats")
                            .method_27692(class_124.field_1063));
                }
            }
        } catch (Exception ignored) {}
    }
}
