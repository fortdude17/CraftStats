package com.craftstats.common.util;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2248;
import net.minecraft.class_2338;

public final class ScreenOpener {

    private static Impl impl = new NoopImpl();

    public static void setImpl(Impl i) { impl = i; }

    public static void openBlockEditor(class_2248 block)                                { impl.openBlockEditor(block); }
    public static void openBlockEditorAt(String posKey, class_2248 block, class_2338 pos) { impl.openBlockEditorAt(posKey, block, pos); }
    public static void openMobEditor(class_1309 entity)                          { impl.openMobEditor(entity); }
    public static void openMobEditorById(String entityTypeId)                      { impl.openMobEditorById(entityTypeId); }
    public static void openItemEditor(String itemId)                               { impl.openItemEditor(itemId); }
    public static void openPlayerEditor(class_1657 player)                             { impl.openPlayerEditor(player); }
    public static void openRandomizeBlock(class_2248 block)                             { impl.openRandomizeBlock(block); }
    public static void openRandomizeMob(class_1309 e)                            { impl.openRandomizeMob(e); }

    public interface Impl {
        void openBlockEditor(class_2248 block);
        void openBlockEditorAt(String posKey, class_2248 block, class_2338 pos);
        void openMobEditor(class_1309 entity);
        void openMobEditorById(String entityTypeId);
        void openItemEditor(String itemId);
        void openPlayerEditor(class_1657 player);
        void openRandomizeBlock(class_2248 block);
        void openRandomizeMob(class_1309 entity);
    }

    private static final class NoopImpl implements Impl {
        public void openBlockEditor(class_2248 b)                               {}
        public void openBlockEditorAt(String k, class_2248 b, class_2338 p)      {}
        public void openMobEditor(class_1309 e)                          {}
        public void openMobEditorById(String id)                           {}
        public void openItemEditor(String id)                              {}
        public void openPlayerEditor(class_1657 p)                             {}
        public void openRandomizeBlock(class_2248 b)                            {}
        public void openRandomizeMob(class_1309 e)                       {}
    }
}
