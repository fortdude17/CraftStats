package com.craftstats.common.mixin;

import com.craftstats.common.stats.BlockStats;
import com.craftstats.common.stats.StatRegistry;
import net.minecraft.class_1540;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4970.class)
public abstract class BlockBehaviourMixin {

    private BlockStats craftstats$getStats() {
        if (!(((Object) this) instanceof class_2248 self)) return null;
        class_2960 id = class_7923.field_41175.method_10221(self);
        if (id == null) return null;
        return StatRegistry.getBlock(id);
    }

    @Inject(method = "onPlace", at = @At("TAIL"), require = 0)
    private void craftstats$scheduleOnPlace(class_2680 state, class_1937 level, class_2338 pos,
                                             class_2680 oldState, boolean isMoving, CallbackInfo ci) {
        if (level.field_9236) return;
        BlockStats stats = craftstats$getStats();
        if (stats != null && stats.canFall && ((Object) this) instanceof class_2248 self) {
            level.method_39279(pos, self, 2);
        }
    }

    @Inject(method = "neighborChanged", at = @At("TAIL"), require = 0)
    private void craftstats$scheduleOnNeighbor(class_2680 state, class_1937 level, class_2338 pos,
                                                class_2248 neighborBlock, class_2338 neighborPos,
                                                boolean movedByPiston, CallbackInfo ci) {
        if (level.field_9236) return;
        BlockStats stats = craftstats$getStats();
        if (stats != null && stats.canFall && ((Object) this) instanceof class_2248 self) {
            level.method_39279(pos, self, 2);
        }
    }

    @Inject(method = "tick", at = @At("HEAD"), require = 0)
    private void craftstats$doFall(class_2680 state, class_3218 level, class_2338 pos,
                                    class_5819 random, CallbackInfo ci) {
        BlockStats stats = craftstats$getStats();
        if (stats == null || !stats.canFall) return;
        if (!(((Object) this) instanceof class_2248 self)) return;
        if (!level.method_8320(pos).method_27852(self)) return;
        class_2680 below = level.method_8320(pos.method_10074());
        if (below.method_26215() || below.method_51176() || below.method_45474()) {
            class_1540.method_40005(level, pos, state);
        }
    }
}
