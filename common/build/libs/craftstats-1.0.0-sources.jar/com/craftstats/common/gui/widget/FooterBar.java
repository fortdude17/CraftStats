package com.craftstats.common.gui.widget;

import com.craftstats.common.gui.CraftStatsScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public class FooterBar {

    private final CraftStatsScreen parent;
    private final int x, y, w, h;

    private class_4185 resetBtn, applyBtn, resetAllBtn;
    private int    unsavedChanges = 0;

    private boolean confirmingResetAll = false;
    private int     confirmTimer       = 0;

    public FooterBar(CraftStatsScreen parent, int x, int y, int w, int h) {
        this.parent = parent;
        this.x = x; this.y = y; this.w = w; this.h = h;
    }

    public void init() {
        int bh = 14;
        int by = y + (h - bh) / 2;

        int bwSmall  = 50;
        int bwDanger = 76;

        int applyX    = x + w - bwSmall - 4;
        int resetX    = applyX - bwSmall - 4;
        int resetAllX = resetX - bwDanger - 4;

        applyBtn = class_4185.method_46430(class_2561.method_43470("Apply"),
                b -> parent.onApply())
                .method_46434(applyX, by, bwSmall, bh).method_46431();
        resetBtn = class_4185.method_46430(class_2561.method_43470("Reset"),
                b -> parent.onReset())
                .method_46434(resetX, by, bwSmall, bh).method_46431();
        resetAllBtn = class_4185.method_46430(class_2561.method_43470("Reset All"),
                b -> handleResetAll())
                .method_46434(resetAllX, by, bwDanger, bh).method_46431();
    }

    private void handleResetAll() {
        if (!confirmingResetAll) {

            confirmingResetAll = true;
            confirmTimer       = 80;
            resetAllBtn.method_25355(class_2561.method_43470("§cConfirm?"));
        } else {

            confirmingResetAll = false;
            confirmTimer       = 0;
            resetAllBtn.method_25355(class_2561.method_43470("Reset All"));
            parent.onResetAll();
        }
    }

    public void update(int unsaved) {
        this.unsavedChanges = unsaved;
    }

    public void tick() {
        if (confirmTimer > 0) {
            confirmTimer--;
            if (confirmTimer == 0) {
                confirmingResetAll = false;
                if (resetAllBtn != null) resetAllBtn.method_25355(class_2561.method_43470("Reset All"));
            }
        }
    }

    public void render(class_332 g, int mx, int my, float delta) {
        class_310 mc = class_310.method_1551();

        String status = unsavedChanges > 0
                ? "● " + unsavedChanges + " unsaved change(s)"
                : "● Connected";
        int color = unsavedChanges > 0 ? 0xFFFFAA00 : 0xFF44BB44;
        g.method_51433(mc.field_1772, status, x + 6, y + (h - 8) / 2, color, false);

        if (confirmingResetAll) {
            String hint = "§eClick again to wipe ALL mod stats from this world!";
            g.method_51433(mc.field_1772, hint,
                    resetAllBtn.method_46426() - mc.field_1772.method_1727(hint) - 6,
                    y + (h - 8) / 2, 0xFFFFEE00, false);
        }

        resetAllBtn.method_25394(g, mx, my, delta);
        resetBtn.method_25394(g, mx, my, delta);
        applyBtn.method_25394(g, mx, my, delta);
    }

    public boolean mouseClicked(double mx, double my, int btn) {
        if (resetAllBtn.method_25402(mx, my, btn)) return true;
        if (resetBtn.method_25402(mx, my, btn))    return true;
        if (applyBtn.method_25402(mx, my, btn))    return true;
        return false;
    }
}
