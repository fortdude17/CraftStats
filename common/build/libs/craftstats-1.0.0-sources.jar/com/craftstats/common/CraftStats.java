package com.craftstats.common;

import com.craftstats.common.command.CraftStatsCommands;
import com.craftstats.common.config.CraftStatsConfig;
import com.craftstats.common.item.ModItems;
import com.craftstats.common.network.CraftStatsNetwork;
import com.craftstats.common.preset.PresetManager;
import com.craftstats.common.registry.ModCreativeTab;
import com.craftstats.common.stats.*;
import com.craftstats.common.util.StatPersistence;
import dev.architectury.event.EventResult;
import dev.architectury.event.events.common.CommandRegistrationEvent;
import dev.architectury.event.events.common.EntityEvent;
import dev.architectury.event.events.common.LifecycleEvent;
import dev.architectury.event.events.common.PlayerEvent;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class CraftStats {

    public static final String MOD_ID = "craftstats";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static void init() {
        CraftStatsConfig.init();
        StatRegistry.init();
        ModItems.register();
        ModCreativeTab.register();
        CraftStatsNetwork.registerServerReceivers();
        PresetManager.init();

        CommandRegistrationEvent.EVENT.register((dispatcher, registry, selection) ->
                CraftStatsCommands.register(dispatcher));

        LifecycleEvent.SERVER_STARTED.register(server -> StatPersistence.init(server));
        LifecycleEvent.SERVER_STOPPING.register(server -> StatPersistence.save());

        EntityEvent.ADD.register((entity, level) -> {
            if (level.method_8608()) return EventResult.pass();
            if (!(entity instanceof class_1309 living) || living instanceof class_1657) return EventResult.pass();

            MobStats uuidStats = StatRegistry.getMobUuid(living.method_5667());
            if (uuidStats != null) {
                entity.method_5682().execute(() -> CraftStatsNetwork.applyMobAttributesToEntity(living, uuidStats));
                return EventResult.pass();
            }
            class_2960 typeId = class_1299.method_5890(living.method_5864());
            if (typeId == null) return EventResult.pass();
            MobStats stats = StatRegistry.getMob(typeId);
            if (stats != null) {

                entity.method_5682().execute(() -> CraftStatsNetwork.applyMobAttributesToEntity(living, stats));
            }
            return EventResult.pass();
        });

        PlayerEvent.PLAYER_JOIN.register(player -> {
            if (!(player instanceof class_3222 sp)) return;
            sp.method_5682().execute(() -> {

                PlayerStats ps = StatRegistry.getPlayer(sp.method_5667());
                if (ps != null) CraftStatsNetwork.applyAllPlayerAttributes(sp, ps);

                if (canAutoGive(sp) && !alreadyHasBook(sp)) {
                    sp.method_31548().method_7394(new class_1799(ModItems.PLAYER_STATS_BOOK.get()));
                }
            });
        });

        LOGGER.info("CraftStats initialised.");
    }

    private static boolean canAutoGive(class_3222 player) {
        if (!player.method_5682().method_3816()) return true;
        return player.method_5687(2);
    }

    private static boolean alreadyHasBook(class_3222 player) {
        for (class_1799 s : player.method_31548().field_7547)
            if (s.method_31574(ModItems.PLAYER_STATS_BOOK.get())) return true;
        for (class_1799 s : player.method_31548().field_7544)
            if (s.method_31574(ModItems.PLAYER_STATS_BOOK.get())) return true;
        return false;
    }
}
