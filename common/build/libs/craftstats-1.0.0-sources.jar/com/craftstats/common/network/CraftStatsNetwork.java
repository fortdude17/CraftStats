package com.craftstats.common.network;

import com.craftstats.common.CraftStats;
import com.craftstats.common.stats.*;
import com.craftstats.common.util.JsonUtil;
import com.craftstats.common.util.StatPersistence;
import dev.architectury.networking.NetworkManager;
import io.netty.buffer.Unpooled;
import java.util.UUID;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.class_5455;
import net.minecraft.class_9129;

public final class CraftStatsNetwork {

    public static final class_2960 APPLY_MOB_STATS =
            class_2960.method_60655(CraftStats.MOD_ID, "apply_mob_stats");
    public static final class_2960 APPLY_BLOCK_STATS =
            class_2960.method_60655(CraftStats.MOD_ID, "apply_block_stats");
    public static final class_2960 APPLY_ITEM_STATS =
            class_2960.method_60655(CraftStats.MOD_ID, "apply_item_stats");
    public static final class_2960 APPLY_PLAYER_STATS =
            class_2960.method_60655(CraftStats.MOD_ID, "apply_player_stats");
    public static final class_2960 RESET_TARGET =
            class_2960.method_60655(CraftStats.MOD_ID, "reset_target");
    public static final class_2960 APPLY_BLOCK_POS_STATS =
            class_2960.method_60655(CraftStats.MOD_ID, "apply_block_pos_stats");
    public static final class_2960 RESET_BLOCK_POS =
            class_2960.method_60655(CraftStats.MOD_ID, "reset_block_pos");
    public static final class_2960 RESET_ALL =
            class_2960.method_60655(CraftStats.MOD_ID, "reset_all");
    public static final class_2960 APPLY_MOB_UUID_STATS =
            class_2960.method_60655(CraftStats.MOD_ID, "apply_mob_uuid_stats");
    public static final class_2960 RESET_MOB_UUID =
            class_2960.method_60655(CraftStats.MOD_ID, "reset_mob_uuid");

    public static void registerServerReceivers() {
        NetworkManager.registerReceiver(NetworkManager.Side.C2S, APPLY_MOB_STATS,
                (buf, ctx) -> {
                    String typeId = buf.method_19772();
                    String json   = buf.method_19772();
                    ctx.queue(() -> {
                        class_3222 player = (class_3222) ctx.getPlayer();
                        if (!hasPermission(player)) return;
                        class_2960 rl = class_2960.method_60654(typeId);
                        MobStats stats = JsonUtil.mobStatsFromJson(json);
                        StatRegistry.setMob(rl, stats);

                        StatPersistence.save();
                    });
                });

        NetworkManager.registerReceiver(NetworkManager.Side.C2S, APPLY_BLOCK_STATS,
                (buf, ctx) -> {
                    String blockId = buf.method_19772();
                    String json    = buf.method_19772();
                    ctx.queue(() -> {
                        if (!hasPermission((class_3222) ctx.getPlayer())) return;
                        StatRegistry.setBlock(class_2960.method_60654(blockId),
                                JsonUtil.blockStatsFromJson(json));
                        StatPersistence.save();
                    });
                });

        NetworkManager.registerReceiver(NetworkManager.Side.C2S, APPLY_ITEM_STATS,
                (buf, ctx) -> {
                    String itemId = buf.method_19772();
                    String json   = buf.method_19772();
                    ctx.queue(() -> {
                        if (!hasPermission((class_3222) ctx.getPlayer())) return;
                        StatRegistry.setItem(class_2960.method_60654(itemId),
                                JsonUtil.itemStatsFromJson(json));
                        StatPersistence.save();
                    });
                });

        NetworkManager.registerReceiver(NetworkManager.Side.C2S, APPLY_PLAYER_STATS,
                (buf, ctx) -> {
                    String uuidStr = buf.method_19772();
                    String json    = buf.method_19772();
                    ctx.queue(() -> {
                        if (!hasPermission((class_3222) ctx.getPlayer())) return;
                        UUID uuid = UUID.fromString(uuidStr);
                        PlayerStats stats = JsonUtil.playerStatsFromJson(json);
                        StatRegistry.setPlayer(uuid, stats);
                        class_3222 target = ((class_3222) ctx.getPlayer()).method_5682()
                                .method_3760().method_14602(uuid);
                        if (target != null) applyAllPlayerAttributes(target, stats);
                        StatPersistence.save();
                    });
                });

        NetworkManager.registerReceiver(NetworkManager.Side.C2S, RESET_TARGET,
                (buf, ctx) -> {
                    String targetType = buf.method_19772();
                    String targetId   = buf.method_19772();
                    ctx.queue(() -> {
                        if (!hasPermission((class_3222) ctx.getPlayer())) return;
                        switch (targetType) {
                            case "mob"    -> StatRegistry.removeMob(class_2960.method_60654(targetId));
                            case "block"  -> StatRegistry.removeBlock(class_2960.method_60654(targetId));
                            case "item"   -> StatRegistry.removeItem(class_2960.method_60654(targetId));
                            case "player" -> StatRegistry.removePlayer(UUID.fromString(targetId));
                        }
                        StatPersistence.save();
                    });
                });

        NetworkManager.registerReceiver(NetworkManager.Side.C2S, APPLY_BLOCK_POS_STATS,
                (buf, ctx) -> {
                    String posKey = buf.method_19772();
                    String json   = buf.method_19772();
                    ctx.queue(() -> {
                        if (!hasPermission((class_3222) ctx.getPlayer())) return;
                        StatRegistry.setBlockAt(posKey, JsonUtil.blockStatsFromJson(json));
                        StatPersistence.save();
                    });
                });

        NetworkManager.registerReceiver(NetworkManager.Side.C2S, RESET_BLOCK_POS,
                (buf, ctx) -> {
                    String posKey = buf.method_19772();
                    ctx.queue(() -> {
                        if (!hasPermission((class_3222) ctx.getPlayer())) return;
                        StatRegistry.removeBlockAt(posKey);
                        StatPersistence.save();
                    });
                });

        NetworkManager.registerReceiver(NetworkManager.Side.C2S, APPLY_MOB_UUID_STATS,
                (buf, ctx) -> {
                    String uuidStr = buf.method_19772();
                    String json    = buf.method_19772();
                    ctx.queue(() -> {
                        class_3222 player = (class_3222) ctx.getPlayer();
                        if (!hasPermission(player)) return;
                        UUID uuid  = UUID.fromString(uuidStr);
                        MobStats stats = JsonUtil.mobStatsFromJson(json);
                        StatRegistry.setMobUuid(uuid, stats);
                        player.method_5682().method_3738().forEach(level ->
                            level.method_27909().forEach(e -> {
                                if (e instanceof class_1309 living && living.method_5667().equals(uuid))
                                    applyMobAttributesToEntity(living, stats);
                            })
                        );
                        StatPersistence.save();
                    });
                });

        NetworkManager.registerReceiver(NetworkManager.Side.C2S, RESET_MOB_UUID,
                (buf, ctx) -> {
                    String uuidStr = buf.method_19772();
                    ctx.queue(() -> {
                        if (!hasPermission((class_3222) ctx.getPlayer())) return;
                        StatRegistry.removeMobUuid(UUID.fromString(uuidStr));
                        StatPersistence.save();
                    });
                });

        NetworkManager.registerReceiver(NetworkManager.Side.C2S, RESET_ALL,
                (buf, ctx) -> {
                    ctx.queue(() -> {
                        class_3222 player = (class_3222) ctx.getPlayer();
                        if (!hasPermission(player)) return;
                        StatRegistry.init();
                        StatPersistence.save();

                        PlayerStats defaults = new PlayerStats();
                        player.method_5682().method_3760().method_14571()
                                .forEach(p -> applyAllPlayerAttributes(p, defaults));
                    });
                });
    }

    public static void registerClientReceivers() {}

    public static void sendApplyMobStats(String entityTypeId, MobStats stats) {
        class_9129 buf = buf();
        buf.method_10814(entityTypeId);
        buf.method_10814(JsonUtil.toCompactJson(stats));
        NetworkManager.sendToServer(APPLY_MOB_STATS, buf);
    }

    public static void sendApplyBlockStats(String blockId, BlockStats stats) {
        class_9129 buf = buf();
        buf.method_10814(blockId);
        buf.method_10814(JsonUtil.toCompactJson(stats));
        NetworkManager.sendToServer(APPLY_BLOCK_STATS, buf);
    }

    public static void sendApplyItemStats(String itemId, ItemStats stats) {
        class_9129 buf = buf();
        buf.method_10814(itemId);
        buf.method_10814(JsonUtil.toCompactJson(stats));
        NetworkManager.sendToServer(APPLY_ITEM_STATS, buf);
    }

    public static void sendApplyPlayerStats(UUID playerUuid, PlayerStats stats) {
        class_9129 buf = buf();
        buf.method_10814(playerUuid.toString());
        buf.method_10814(JsonUtil.toCompactJson(stats));
        NetworkManager.sendToServer(APPLY_PLAYER_STATS, buf);
    }

    public static void sendReset(String targetType, String targetId) {
        class_9129 buf = buf();
        buf.method_10814(targetType);
        buf.method_10814(targetId);
        NetworkManager.sendToServer(RESET_TARGET, buf);
    }

    public static void sendApplyBlockPosStats(String posKey, BlockStats stats) {
        class_9129 buf = buf();
        buf.method_10814(posKey);
        buf.method_10814(JsonUtil.toCompactJson(stats));
        NetworkManager.sendToServer(APPLY_BLOCK_POS_STATS, buf);
    }

    public static void sendResetBlockPos(String posKey) {
        class_9129 buf = buf();
        buf.method_10814(posKey);
        NetworkManager.sendToServer(RESET_BLOCK_POS, buf);
    }

    public static void sendApplyMobUuidStats(UUID entityUuid, MobStats stats) {
        class_9129 buf = buf();
        buf.method_10814(entityUuid.toString());
        buf.method_10814(JsonUtil.toCompactJson(stats));
        NetworkManager.sendToServer(APPLY_MOB_UUID_STATS, buf);
    }

    public static void sendResetMobUuid(UUID entityUuid) {
        class_9129 buf = buf();
        buf.method_10814(entityUuid.toString());
        NetworkManager.sendToServer(RESET_MOB_UUID, buf);
    }

    public static void sendResetAll() {
        NetworkManager.sendToServer(RESET_ALL, buf());
    }

    private static class_9129 buf() {
        return new class_9129(Unpooled.buffer(), class_5455.field_40585);
    }

    private static boolean hasPermission(class_3222 player) {
        if (player == null) return false;

        if (!player.method_5682().method_3816()) return true;
        return player.method_5687(2) || player.method_7337();
    }

    private static void applyMobStatsToLoadedEntities(class_3222 requestingPlayer,
                                                       class_2960 typeId, MobStats stats) {
        requestingPlayer.method_5682().method_3738().forEach(level ->
                level.method_27909().forEach(e -> {
                    if (e instanceof class_1309 living) {
                        if (typeId.equals(class_1299.method_5890(living.method_5864())))
                            applyMobAttributesToEntity(living, stats);
                    }
                })
        );
    }

    public static void applyMobAttributesToEntity(class_1309 entity, MobStats stats) {

        if (stats.maxHealth >= 0)        setAttr(entity, class_5134.field_23716,          stats.maxHealth);
        if (stats.attackDamage >= 0)     setAttr(entity, class_5134.field_23721,       stats.attackDamage);
        if (stats.armor >= 0)            setAttr(entity, class_5134.field_23724,               stats.armor);
        if (stats.knockbackResist >= 0)  setAttr(entity, class_5134.field_23718, stats.knockbackResist);
        if (stats.moveSpeed >= 0)        setAttr(entity, class_5134.field_23719,      stats.moveSpeed);
        if (stats.followRange >= 0)      setAttr(entity, class_5134.field_23717,        stats.followRange);
        if (stats.sizeScale >= 0)        setAttr(entity, class_5134.field_47760,               stats.sizeScale);
        if (entity.method_6032() > entity.method_6063())
            entity.method_6033(entity.method_6063());
    }

    public static void applyAllPlayerAttributes(class_3222 target, PlayerStats stats) {

        setAttr(target, class_5134.field_23716,                    stats.maxHealth);
        setAttr(target, class_5134.field_23721,                 stats.baseDamage);
        setAttr(target, class_5134.field_23723,                  stats.attackSpeed);
        setAttr(target, class_5134.field_23719,                stats.walkSpeed);
        setAttr(target, class_5134.field_23720,                  stats.flySpeed);
        setAttr(target, class_5134.field_47761,                   stats.stepHeight);
        setAttr(target, class_5134.field_23728,                 stats.jumpForce);
        setAttr(target, class_5134.field_47759,      stats.reachDistance);
        setAttr(target, class_5134.field_47758,       stats.reachDistance);
        setAttr(target, class_5134.field_51583, stats.drownImmune ? 10_000.0 : 0.0);

        setAttr(target, class_5134.field_23724,                         stats.armor);
        setAttr(target, class_5134.field_23725,               stats.armorToughness);
        setAttr(target, class_5134.field_23718,          stats.knockbackResistance);
        setAttr(target, class_5134.field_23726,                          stats.luck);
        setAttr(target, class_5134.field_23722,              stats.attackKnockback);

        setAttr(target, class_5134.field_49078,                       stats.gravity);
        setAttr(target, class_5134.field_49077,        stats.fallDamageMultiplier);
        setAttr(target, class_5134.field_49079,            stats.safeFallDistance);
        setAttr(target, class_5134.field_51579,                  stats.burningTime);
        setAttr(target, class_5134.field_51580, stats.explosionKbResistance);
        setAttr(target, class_5134.field_51581,             stats.miningEfficiency);
        setAttr(target, class_5134.field_51582,           stats.movementEfficiency);
        setAttr(target, class_5134.field_51584,                stats.sneakingSpeed);
        setAttr(target, class_5134.field_51576,        stats.submergedMiningSpeed);
        setAttr(target, class_5134.field_51577,         stats.sweepingDamageRatio);
        setAttr(target, class_5134.field_51578,     stats.waterMovementEfficiency);
        setAttr(target, class_5134.field_45124,                stats.maxAbsorption);

        if (target.method_6032() > target.method_6063())
            target.method_6033(target.method_6063());
    }

    private static void setAttr(class_1309 entity,
                                  net.minecraft.class_6880<net.minecraft.class_1320> attr,
                                  double value) {
        var instance = entity.method_5996(attr);
        if (instance != null) instance.method_6192(value);
    }
}
