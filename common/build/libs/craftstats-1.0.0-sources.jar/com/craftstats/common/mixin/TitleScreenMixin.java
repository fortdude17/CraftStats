package com.craftstats.common.mixin;

import com.craftstats.common.gui.StatResetScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {
    protected TitleScreenMixin(class_2561 title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void craftstats$addButton(CallbackInfo ci) {
        int bw = 120, bh = 20;

        method_37063(class_4185.method_46430(
                class_2561.method_43470("CraftStats"),
                b -> class_310.method_1551().method_1507(new StatResetScreen(this)))
                .method_46434(4, this.field_22790 - bh - 30, bw, bh)
                .method_46431());
    }
}
