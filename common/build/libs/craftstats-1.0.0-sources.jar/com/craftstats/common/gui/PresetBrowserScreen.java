package com.craftstats.common.gui;

import com.craftstats.common.gui.CraftStatsScreen;
import com.craftstats.common.preset.Preset;
import com.craftstats.common.preset.PresetManager;
import com.craftstats.common.stats.*;
import com.craftstats.common.util.JsonUtil;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class PresetBrowserScreen extends class_437 {

    private final class_437        parent;
    private final TargetType    targetType;
    private final Object        currentStats;
    private final String        targetId;

    private List<Preset> presets;
    private int          selectedIdx = -1;
    private int          scrollOffset = 0;

    private static final int ROW_H = 14;
    private static final int LIST_X = 6;
    private static final int LIST_W = 180;
    private static final int PAD    = 6;

    private class_4185 loadBtn, deleteBtn, saveBtn, importBtn, exportBtn, closeBtn;
    private class_342 importExportBox, nameBox;

    public PresetBrowserScreen(class_437 parent, TargetType type, Object currentStats, String targetId) {
        super(class_2561.method_43470("Preset Browser — " + type.name()));
        this.parent       = parent;
        this.targetType   = type;
        this.currentStats = currentStats;
        this.targetId     = targetId;
    }

    @Override
    protected void method_25426() {
        presets = PresetManager.getForType(targetType);
        int bw = 60, bh = 14;
        int rightX = LIST_X + LIST_W + PAD;
        int rightY = PAD + 14;

        loadBtn   = class_4185.method_46430(class_2561.method_43470("Load"),   b -> loadSelected()).method_46434(rightX, rightY,       bw, bh).method_46431();
        deleteBtn = class_4185.method_46430(class_2561.method_43470("Delete"), b -> deleteSelected()).method_46434(rightX, rightY + 18, bw, bh).method_46431();
        saveBtn   = class_4185.method_46430(class_2561.method_43470("Save Current"), b -> saveCurrentAsPreset()).method_46434(rightX, rightY + 36, bw + 20, bh).method_46431();
        importBtn = class_4185.method_46430(class_2561.method_43470("Import"), b -> importFromBox()).method_46434(rightX, rightY + 54, bw, bh).method_46431();
        exportBtn = class_4185.method_46430(class_2561.method_43470("Export"), b -> exportToBox()).method_46434(rightX + bw + 4, rightY + 54, bw, bh).method_46431();
        closeBtn  = class_4185.method_46430(class_2561.method_43470("Close"),  b -> method_25419()).method_46434(this.field_22789 - 60 - PAD, this.field_22790 - bh - PAD, 60, bh).method_46431();

        nameBox = new class_342(this.field_22793, rightX, rightY + 74, 130, bh, class_2561.method_43470("Preset name"));
        nameBox.method_1880(64);

        importExportBox = new class_342(this.field_22793, PAD, this.field_22790 - bh * 3 - PAD * 2, this.field_22789 - PAD * 2, bh * 2,
                class_2561.method_43470("Import/Export JSON"));
        importExportBox.method_1880(8192);

        method_37063(loadBtn);
        method_37063(deleteBtn);
        method_37063(saveBtn);
        method_37063(importBtn);
        method_37063(exportBtn);
        method_37063(closeBtn);
        method_37063(nameBox);
        method_37063(importExportBox);
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        this.method_25420(g, mx, my, delta);
        g.method_25294(0, 0, this.field_22789, this.field_22790, 0xCC000000);
        g.method_25294(LIST_X, PAD + 12, LIST_X + LIST_W, this.field_22790 - 70, 0xFF1A1A2E);

        g.method_51433(this.field_22793, "Presets — " + targetType.name(), LIST_X, PAD, 0xFFFFFFFF, false);

        int listH = this.field_22790 - 70 - PAD - 12;
        int visRows = listH / ROW_H;
        g.method_44379(LIST_X, PAD + 12, LIST_X + LIST_W, PAD + 12 + listH);
        for (int i = scrollOffset; i < Math.min(presets.size(), scrollOffset + visRows); i++) {
            Preset p  = presets.get(i);
            int ry = PAD + 12 + (i - scrollOffset) * ROW_H;
            boolean sel = i == selectedIdx;
            if (sel) g.method_25294(LIST_X, ry, LIST_X + LIST_W, ry + ROW_H, 0xFF0F3460);
            String label = (p.readonly ? "[R] " : "     ") + p.name;
            g.method_51433(this.field_22793, label, LIST_X + 2, ry + 3, sel ? 0xFFFFFFFF : 0xFFCCCCCC, false);
        }
        g.method_44380();

        if (selectedIdx >= 0 && selectedIdx < presets.size()) {
            g.method_51433(this.field_22793, "Selected: " + presets.get(selectedIdx).name,
                    LIST_X + LIST_W + PAD, PAD, 0xFF44CCFF, false);
        }

        super.method_25394(g, mx, my, delta);
    }

    @Override
    public boolean method_25402(double mx, double my, int btn) {
        int listH = this.field_22790 - 70 - PAD - 12;
        if (mx >= LIST_X && mx < LIST_X + LIST_W && my >= PAD + 12 && my < PAD + 12 + listH) {
            int row = ((int) my - PAD - 12) / ROW_H + scrollOffset;
            if (row >= 0 && row < presets.size()) { selectedIdx = row; return true; }
        }
        return super.method_25402(mx, my, btn);
    }

    @Override
    public boolean method_25401(double mx, double my, double h, double v) {
        int listH = this.field_22790 - 70 - PAD - 12;
        if (mx >= LIST_X && mx < LIST_X + LIST_W) {
            int maxScroll = Math.max(0, presets.size() - listH / ROW_H);
            scrollOffset = (int) Math.max(0, Math.min(maxScroll, scrollOffset - v * 3));
            return true;
        }
        return super.method_25401(mx, my, h, v);
    }

    private void loadSelected() {
        if (selectedIdx < 0 || selectedIdx >= presets.size()) return;
        Preset p = presets.get(selectedIdx);
        if (p.targetType != targetType) {
            class_310.method_1551().field_1724.method_43496(
                    class_2561.method_43470("Type mismatch: preset is " + p.targetType));
            return;
        }

        if (parent instanceof CraftStatsScreen cs) {
            switch (targetType) {
                case MOB    -> cs.selectMobById(targetId);
                case BLOCK  -> cs.selectBlockById(targetId);
                case ITEM   -> cs.selectItemById(targetId);
            }
        }
        method_25419();
    }

    private void deleteSelected() {
        if (selectedIdx < 0 || selectedIdx >= presets.size()) return;
        Preset p = presets.get(selectedIdx);
        if (p.readonly) {
            class_310.method_1551().field_1724.method_43496(class_2561.method_43470("Cannot delete built-in preset."));
            return;
        }
        PresetManager.deletePreset(p.name);
        presets = PresetManager.getForType(targetType);
        selectedIdx = -1;
    }

    private void saveCurrentAsPreset() {
        String name = nameBox.method_1882().trim();
        if (name.isEmpty()) name = "preset_" + System.currentTimeMillis();
        Preset p = new Preset(name, targetType, currentStats);
        PresetManager.savePreset(p);
        presets = PresetManager.getForType(targetType);
    }

    private void importFromBox() {
        String json = importExportBox.method_1882().trim();
        if (json.isEmpty()) return;
        try {
            Preset p = JsonUtil.GSON.fromJson(json, Preset.class);
            if (p != null && p.name != null) PresetManager.savePreset(p);
            presets = PresetManager.getForType(targetType);
        } catch (Exception e) {
            class_310.method_1551().field_1724.method_43496(class_2561.method_43470("Invalid preset JSON."));
        }
    }

    private void exportToBox() {
        if (selectedIdx < 0 || selectedIdx >= presets.size()) return;
        importExportBox.method_1852(JsonUtil.toJson(presets.get(selectedIdx)));
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(parent);
    }

    @Override
    public boolean method_25421() { return false; }
}
