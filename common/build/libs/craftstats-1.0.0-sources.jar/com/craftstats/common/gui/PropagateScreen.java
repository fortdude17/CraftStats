package com.craftstats.common.gui;

import com.craftstats.common.propagate.PropagateManager;
import com.craftstats.common.stats.*;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class PropagateScreen extends class_437 {

    private final class_2960 targetType;
    private final MobStats         newStats;
    private final MobStats         prevStats;
    private final PropagateManager.PropagatePreview preview;

    private class_342 confirmBox;
    private class_4185  executeBtn, cancelBtn;
    private boolean perInstance = false;

    private static final int PAD = 8;

    public PropagateScreen(class_2960 targetType, MobStats newStats, MobStats prevStats) {
        super(class_2561.method_43470("Propagate Changes"));
        this.targetType = targetType;
        this.newStats   = newStats;
        this.prevStats  = prevStats;
        this.preview    = PropagateManager.previewMob(targetType, newStats, prevStats);
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int bottomY = this.field_22790 - 40;

        confirmBox = new class_342(this.field_22793, cx - 60, bottomY - 20, 120, 16,
                class_2561.method_43470("Type CONFIRM"));
        confirmBox.method_1880(10);
        method_37063(confirmBox);

        executeBtn = class_4185.method_46430(class_2561.method_43470("Execute"),
                b -> { if (confirmBox.method_1882().equals("CONFIRM")) execute(); })
                .method_46434(cx + PAD, bottomY, 60, 16).method_46431();
        cancelBtn  = class_4185.method_46430(class_2561.method_43470("Cancel"), b -> method_25419())
                .method_46434(cx - 64, bottomY, 60, 16).method_46431();
        method_37063(executeBtn);
        method_37063(cancelBtn);

        class_4185 instanceBtn = class_4185.method_46430(
                class_2561.method_43470(perInstance ? "Mode: Per-Instance" : "Mode: Global"),
                b -> { perInstance = !perInstance;
                    b.method_25355(class_2561.method_43470(perInstance ? "Mode: Per-Instance" : "Mode: Global")); })
                .method_46434(PAD, PAD + 50, 110, 16).method_46431();
        method_37063(instanceBtn);

        if (PropagateManager.canUndo()) {
            class_4185 undoBtn = class_4185.method_46430(class_2561.method_43470("Undo Last"),
                    b -> { PropagateManager.undoLastPropagate(); method_25419(); })
                    .method_46434(PAD, PAD + 70, 90, 16).method_46431();
            method_37063(undoBtn);
        }
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        this.method_25420(g, mx, my, delta);
        g.method_25294(0, 0, this.field_22789, this.field_22790, 0xCC000000);

        g.method_25300(this.field_22793, "Propagate Changes", this.field_22789 / 2, PAD, 0xFFFFFFFF);
        g.method_51433(this.field_22793, "Target: " + targetType, PAD, PAD + 14, 0xFFCCCCCC, false);
        g.method_51433(this.field_22793, "Affected entities: " + preview.affectedCount(), PAD, PAD + 26, 0xFFFFAA44, false);
        g.method_51433(this.field_22793, "Type CONFIRM to proceed:", this.field_22789 / 2 - 60, this.field_22790 - 60, 0xFFFF4444, false);

        List<PropagateManager.DiffEntry> diffs = preview.diff();
        int rowY = PAD + 44;
        g.method_51433(this.field_22793, "Changes:", PAD + 120, rowY, 0xFFAAAAAA, false);
        rowY += 12;
        for (PropagateManager.DiffEntry d : diffs) {
            g.method_51433(this.field_22793, d.field() + ": " + d.oldValue() + " → " + d.newValue(),
                    PAD + 120, rowY, 0xFFFFFF44, false);
            rowY += 10;
            if (rowY > this.field_22790 - 80) break;
        }

        super.method_25394(g, mx, my, delta);
    }

    private void execute() {
        PropagateManager.propagateMob(targetType, newStats, perInstance, prevStats);
        method_25419();
    }

    @Override
    public boolean method_25421() { return false; }
}
