package com.craftstats.common.mixin;

import com.craftstats.common.gui.CraftStatsScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_433.class)
public abstract class PauseScreenMixin extends class_437 {
    protected PauseScreenMixin(class_2561 title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void craftstats$addButton(CallbackInfo ci) {
        class_310 mc = class_310.method_1551();

        boolean singleplayer = mc.method_1576() != null;
        boolean canUse = singleplayer
                || (mc.field_1724 != null && (mc.field_1724.method_5687(2) || mc.field_1724.method_7337()));
        if (!canUse) return;

        int maxBottom = this.field_22790 / 4 + 8;
        for (var child : this.method_25396()) {
            if (child instanceof class_339 w)
                maxBottom = Math.max(maxBottom, w.method_46427() + w.method_25364());
        }
        method_37063(class_4185.method_46430(
                class_2561.method_43470("CraftStats"),
                b -> class_310.method_1551().method_1507(new CraftStatsScreen()))
                .method_46434(this.field_22789 / 2 - 100, maxBottom + 4, 200, 20)
                .method_46431());
    }
}
