package com.craftstats.common.mixin;

import com.craftstats.common.stats.ItemStats;
import com.craftstats.common.stats.StatRegistry;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1665.class)
public abstract class AbstractArrowMixin {

    @Inject(method = "getBaseDamage", at = @At("HEAD"), cancellable = true)
    private void craftstats$arrowDamage(CallbackInfoReturnable<Double> cir) {
        class_1665 self = (class_1665) (Object) this;

        class_1799 weapon = self.method_59958();
        if (weapon != null && !weapon.method_7960()) {
            class_2960 id = class_7923.field_41178.method_10221(weapon.method_7909());
            ItemStats stats = StatRegistry.getItem(id);
            if (stats != null && stats.attackDamage > 0) {
                cir.setReturnValue(stats.attackDamage);
            }
        }
    }
}
