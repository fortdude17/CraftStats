package com.craftstats.common.util;

import com.craftstats.common.mixin.BlockBehaviourAccessor;
import com.craftstats.common.mixin.BlockBehaviourPropertiesAccessor;
import com.craftstats.common.stats.BlockStats;
import net.minecraft.class_2248;
import net.minecraft.class_2358;
import net.minecraft.class_2399;
import net.minecraft.class_2413;
import net.minecraft.class_2490;
import net.minecraft.class_2492;
import net.minecraft.class_2541;
import net.minecraft.class_2563;
import net.minecraft.class_3736;
import net.minecraft.class_3830;
import net.minecraft.class_3922;
import net.minecraft.class_4622;
import net.minecraft.class_4970;
import net.minecraft.class_5635;

public final class BlockStatExtractor {

    public static BlockStats extractFrom(class_2248 block) {
        BlockStats stats = new BlockStats();

        try {
            class_4970.class_2251 props =
                    ((BlockBehaviourAccessor)(Object)block).craftstats$getBlockProperties();
            BlockBehaviourPropertiesAccessor propsAcc =
                    (BlockBehaviourPropertiesAccessor)(Object)props;

            stats.hardness    = propsAcc.craftstats$getDestroyTime();
            stats.noCollision = !propsAcc.craftstats$getHasCollision();
        } catch (Exception ignored) {
            stats.hardness    = 1.5f;
            stats.noCollision = false;
        }

        stats.blastResistance = block.method_9520();
        stats.slipperiness    = block.method_9499();
        stats.lightEmission   = block.method_9564().method_26213();

        if (block instanceof class_2399 || block instanceof class_2541
                || block instanceof class_3736) {
            stats.climbable = true;
        }

        if (block instanceof class_5635) {
            stats.freezeOnStep = true;
        }

        if (block instanceof class_2413) {
            stats.stepDamage = 1.0f;
        }

        if (block instanceof class_2490) {
            stats.bounceFactor = 0.8f;
            stats.slipperiness = 0.8f;
        }

        if (block instanceof class_3922 || block instanceof class_2358) {
            stats.stepDamage = 1.0f;
        }

        if (block instanceof class_2492) {
            stats.speedModifier = 0.4f;
        }

        if (block instanceof class_4622) {
            stats.speedModifier = 0.4f;
            stats.bounceFactor  = 0.0f;
        }

        if (block instanceof class_2563 || block instanceof class_3830) {
            stats.stepDamage = 1.0f;
        }

        return stats;
    }

    private BlockStatExtractor() {}
}
