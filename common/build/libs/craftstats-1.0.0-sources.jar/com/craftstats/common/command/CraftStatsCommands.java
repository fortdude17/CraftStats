package com.craftstats.common.command;

import com.craftstats.common.config.CraftStatsConfig;
import com.craftstats.common.item.ModItems;
import com.craftstats.common.preset.Preset;
import com.craftstats.common.preset.PresetManager;
import com.craftstats.common.randomize.RandomizeManager;
import com.craftstats.common.stats.*;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public final class CraftStatsCommands {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("craftstats")
                .requires(src -> src.method_9259(2))

                .then(class_2170.method_9247("give")
                    .then(class_2170.method_9244("player", class_2186.method_9305())
                        .executes(ctx -> {
                            class_3222 target = class_2186.method_9315(ctx, "player");
                            class_1799 wand = new class_1799(ModItems.CRAFT_WAND.get());
                            target.method_31548().method_7394(wand);
                            ctx.getSource().method_9226(() -> class_2561.method_43470(
                                    "Gave Craft Wand to " + target.method_5477().getString()), true);
                            return 1;
                        })
                    )
                )

                .then(class_2170.method_9247("reload")
                    .executes(ctx -> {
                        CraftStatsConfig.load();
                        PresetManager.reload();
                        ctx.getSource().method_9226(() -> class_2561.method_43470("CraftStats config reloaded."), true);
                        return 1;
                    })
                )

                .then(class_2170.method_9247("reset")
                    .then(class_2170.method_9244("target_type", StringArgumentType.word())
                        .then(class_2170.method_9244("target_id", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                String ttype = StringArgumentType.getString(ctx, "target_type");
                                String tid   = StringArgumentType.getString(ctx, "target_id");
                                class_2960 rl = class_2960.method_60654(tid);
                                switch (ttype) {
                                    case "mob"   -> StatRegistry.removeMob(rl);
                                    case "block" -> StatRegistry.removeBlock(rl);
                                    case "item"  -> StatRegistry.removeItem(rl);
                                    default -> {
                                        ctx.getSource().method_9213(class_2561.method_43470("Unknown target type: " + ttype));
                                        return 0;
                                    }
                                }
                                ctx.getSource().method_9226(() -> class_2561.method_43470(
                                        "Reset " + ttype + " " + tid + " to vanilla defaults."), true);
                                return 1;
                            })
                        )
                    )
                )

                .then(class_2170.method_9247("preset")
                    .then(class_2170.method_9247("load")
                        .then(class_2170.method_9244("preset_name", StringArgumentType.word())
                            .then(class_2170.method_9244("target_type", StringArgumentType.word())
                                .then(class_2170.method_9244("target_id", StringArgumentType.greedyString())
                                    .executes(ctx -> {
                                        String pname = StringArgumentType.getString(ctx, "preset_name");
                                        String ttype = StringArgumentType.getString(ctx, "target_type");
                                        String tid   = StringArgumentType.getString(ctx, "target_id");
                                        TargetType type = TargetType.valueOf(ttype.toUpperCase());
                                        Optional<Preset> preset = PresetManager.getForType(type).stream()
                                                .filter(p -> p.name.equals(pname)).findFirst();
                                        if (preset.isEmpty()) {
                                            ctx.getSource().method_9213(class_2561.method_43470("Preset not found: " + pname));
                                            return 0;
                                        }
                                        class_2960 rl = class_2960.method_60654(tid);
                                        applyPreset(rl, type, preset.get());
                                        ctx.getSource().method_9226(() -> class_2561.method_43470(
                                                "Applied preset '" + pname + "' to " + tid), true);
                                        return 1;
                                    })
                                )
                            )
                        )
                    )
                )

                .then(class_2170.method_9247("randomize")
                    .then(class_2170.method_9244("target_type", StringArgumentType.word())
                        .then(class_2170.method_9244("target_id", StringArgumentType.word())
                            .executes(ctx -> doRandomize(ctx.getSource(),
                                    StringArgumentType.getString(ctx, "target_type"),
                                    StringArgumentType.getString(ctx, "target_id"),
                                    RandomizeManager.newSeed()))
                            .then(class_2170.method_9244("seed", LongArgumentType.longArg())
                                .executes(ctx -> doRandomize(ctx.getSource(),
                                        StringArgumentType.getString(ctx, "target_type"),
                                        StringArgumentType.getString(ctx, "target_id"),
                                        LongArgumentType.getLong(ctx, "seed")))
                            )
                        )
                    )
                )
        );
    }

    private static void applyPreset(class_2960 rl, TargetType type, Preset preset) {
        switch (type) {
            case MOB   -> StatRegistry.setMob(rl, (MobStats) preset.stats);
            case BLOCK -> StatRegistry.setBlock(rl, (BlockStats) preset.stats);
            case ITEM  -> StatRegistry.setItem(rl, (ItemStats) preset.stats);
        }
    }

    private static int doRandomize(class_2168 src, String ttype, String tid, long seed) {
        class_2960 rl = class_2960.method_60654(tid);
        switch (ttype) {
            case "mob" -> {
                MobStats vanilla = StatRegistry.getMob(rl);
                if (vanilla == null) vanilla = new MobStats();
                StatRegistry.setMob(rl, RandomizeManager.randomizeMob(vanilla, seed));
            }
            case "block" -> {
                BlockStats vanilla = StatRegistry.getBlock(rl);
                if (vanilla == null) vanilla = new BlockStats();
                StatRegistry.setBlock(rl, RandomizeManager.randomizeBlock(vanilla, seed));
            }
            case "item" -> {
                ItemStats vanilla = StatRegistry.getItem(rl);
                if (vanilla == null) vanilla = new ItemStats();
                StatRegistry.setItem(rl, RandomizeManager.randomizeItem(vanilla, seed));
            }
            default -> {
                src.method_9213(class_2561.method_43470("Unknown target type: " + ttype));
                return 0;
            }
        }
        final long s = seed;
        src.method_9226(() -> class_2561.method_43470(
                "Randomized " + ttype + " " + tid + " with seed " + s), true);
        return 1;
    }
}
