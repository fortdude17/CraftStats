package com.craftstats.common.mixin;

import com.craftstats.common.stats.BlockStats;
import com.craftstats.common.stats.StatRegistry;
import net.minecraft.class_1303;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3619;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class_4971.class)
public abstract class BlockBehaviourStateMixin {

    @Inject(method = "getDestroySpeed", at = @At("HEAD"), cancellable = true)
    private void craftstats$hardness(class_1922 level, class_2338 pos,
                                      CallbackInfoReturnable<Float> cir) {
        class_2680 state = (class_2680)(Object)this;

        if (level instanceof class_1937 lv) {
            String posKey = StatRegistry.makePosKey(lv.method_27983(), pos);
            BlockStats posStats = StatRegistry.getBlockAt(posKey);
            if (posStats != null && posStats.hardness >= 0) { cir.setReturnValue(posStats.hardness); return; }
        }
        class_2960 id = class_7923.field_41175.method_10221(state.method_26204());
        BlockStats stats = StatRegistry.getBlock(id);
        if (stats != null && stats.hardness >= 0) cir.setReturnValue(stats.hardness);
    }

    @Inject(method = "getLightEmission", at = @At("HEAD"), cancellable = true)
    private void craftstats$lightEmission(CallbackInfoReturnable<Integer> cir) {
        class_2680 state = (class_2680)(Object)this;
        class_2960 id = class_7923.field_41175.method_10221(state.method_26204());
        BlockStats stats = StatRegistry.getBlock(id);
        if (stats != null && stats.lightEmission >= 0) cir.setReturnValue(stats.lightEmission);
    }

    @Inject(
        method = "getCollisionShape(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/phys/shapes/CollisionContext;)Lnet/minecraft/world/phys/shapes/VoxelShape;",
        at = @At("HEAD"), cancellable = true, require = 0
    )
    private void craftstats$noCollision(class_1922 level, class_2338 pos, class_3726 ctx,
                                         CallbackInfoReturnable<class_265> cir) {
        class_2680 state = (class_2680)(Object)this;

        if (level instanceof class_1937 lv) {
            String posKey = StatRegistry.makePosKey(lv.method_27983(), pos);
            BlockStats ps = StatRegistry.getBlockAt(posKey);
            if (ps != null && ps.noCollision) { cir.setReturnValue(class_259.method_1073()); return; }
        }
        class_2960 id = class_7923.field_41175.method_10221(state.method_26204());
        BlockStats stats = StatRegistry.getBlock(id);
        if (stats != null && stats.noCollision) cir.setReturnValue(class_259.method_1073());
    }

    @Inject(method = "getPistonPushReaction", at = @At("HEAD"), cancellable = true, require = 0)
    private void craftstats$pushReaction(CallbackInfoReturnable<class_3619> cir) {
        class_2680 state = (class_2680)(Object)this;
        class_2960 id = class_7923.field_41175.method_10221(state.method_26204());
        BlockStats stats = StatRegistry.getBlock(id);
        if (stats == null || stats.pushReaction.equals("normal")) return;
        class_3619 reaction = switch (stats.pushReaction) {
            case "destroy"   -> class_3619.field_15971;
            case "block"     -> class_3619.field_15972;
            case "ignore"    -> class_3619.field_15975;
            case "push_only" -> class_3619.field_15970;
            default          -> class_3619.field_15974;
        };
        cir.setReturnValue(reaction);
    }

    @Inject(method = "requiresCorrectToolForDrops", at = @At("HEAD"), cancellable = true, require = 0)
    private void craftstats$requiresCorrectTool(CallbackInfoReturnable<Boolean> cir) {
        class_2680 state = (class_2680)(Object)this;
        class_2960 id = class_7923.field_41175.method_10221(state.method_26204());
        BlockStats stats = StatRegistry.getBlock(id);
        if (stats != null && stats.requiresCorrectTool) cir.setReturnValue(true);
    }

    @Inject(method = "spawnAfterBreak", at = @At("HEAD"), cancellable = true, require = 0)
    private void craftstats$dropXp(class_3218 level, class_2338 pos, class_1799 tool,
                                    boolean dropExperience, CallbackInfo ci) {
        if (!dropExperience) return;
        class_2680 state = (class_2680)(Object)this;

        String posKey = StatRegistry.makePosKey(level.method_27983(), pos);
        BlockStats ps = StatRegistry.getBlockAt(posKey);
        if (ps != null && ps.dropXp >= 0) {
            if (ps.dropXp > 0) class_1303.method_31493(level, class_243.method_24953(pos), ps.dropXp);
            ci.cancel();
            return;
        }

        class_2960 id = class_7923.field_41175.method_10221(state.method_26204());
        if (id == null) return;
        BlockStats stats = StatRegistry.getBlock(id);
        if (stats != null && stats.dropXp >= 0) {
            if (stats.dropXp > 0) class_1303.method_31493(level, class_243.method_24953(pos), stats.dropXp);
            ci.cancel();
        }
    }
}
