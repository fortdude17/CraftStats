package com.craftstats.common.mixin;

import com.craftstats.common.stats.MobStats;
import com.craftstats.common.stats.StatRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
public abstract class MobMixin {

    @Inject(method = "removeWhenFarAway", at = @At("HEAD"), cancellable = true, require = 0)
    private void craftstats$canDespawn(double distSq, CallbackInfoReturnable<Boolean> cir) {
        class_1308 self = (class_1308)(Object)this;
        if (self.method_37908().method_8608()) return;
        MobStats ms = StatRegistry.getMobUuid(self.method_5667());
        if (ms == null) {
            class_2960 typeId = class_1299.method_5890(self.method_5864());
            if (typeId == null) return;
            ms = StatRegistry.getMob(typeId);
        }
        if (ms != null && !ms.canDespawn) cir.setReturnValue(false);
    }
}
