package com.craftstats.common.mixin;

import com.craftstats.common.stats.BlockStats;
import com.craftstats.common.stats.StatRegistry;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2248.class)
public abstract class BlockMixin {

    @Inject(method = "getFriction", at = @At("HEAD"), cancellable = true, require = 0)
    private void craftstats$friction(CallbackInfoReturnable<Float> cir) {
        class_2248 self = (class_2248)(Object)this;
        class_2960 id = class_7923.field_41175.method_10221(self);
        if (id == null) return;
        BlockStats stats = StatRegistry.getBlock(id);
        if (stats != null && stats.slipperiness >= 0) cir.setReturnValue(stats.slipperiness);
    }

    @Inject(method = "getExplosionResistance", at = @At("HEAD"), cancellable = true, require = 0)
    private void craftstats$blastResistance(CallbackInfoReturnable<Float> cir) {
        class_2248 self = (class_2248)(Object)this;
        class_2960 id = class_7923.field_41175.method_10221(self);
        if (id == null) return;
        BlockStats stats = StatRegistry.getBlock(id);
        if (stats != null && stats.blastResistance >= 0) cir.setReturnValue(stats.blastResistance);
    }
}
