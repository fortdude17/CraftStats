package com.craftstats.common.gui;

import com.craftstats.common.gui.panel.FieldDef;
import com.craftstats.common.gui.panel.FieldRow;
import com.craftstats.common.gui.panel.StatEditorPanel;
import com.craftstats.common.network.CraftStatsNetwork;
import com.craftstats.common.stats.BlockStats;
import com.craftstats.common.stats.StatRegistry;
import com.craftstats.common.util.BlockStatExtractor;
import com.craftstats.common.util.ScreenOpener;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7923;

public class BlockPosScreen extends class_437 {

    private static final int HEADER_H = 40;
    private static final int TAB_H    = 18;
    private static final int FOOTER_H = 28;
    private static final int PAD      = 6;
    private static final int ROW_H    = 18;

    private static final String[] TAB_NAMES = {"Physical", "Properties", "Step-On FX", "Rendering"};

    private final String   posKey;
    private final class_2248    block;
    private final class_2338 pos;
    private final String   blockId;

    private BlockStats working;
    private int        activeTab    = 0;
    private int        scrollOffset = 0;
    private int        unsaved      = 0;

    private final List<FieldRow> rows = new ArrayList<>();

    private class_4185 applyBtn, resetBtn, editTypeBtn, fromBlockBtn, closeBtn;
    private final class_4185[] tabBtns = new class_4185[TAB_NAMES.length];

    public BlockPosScreen(String posKey, class_2248 block, class_2338 pos) {
        super(class_2561.method_43470("Block Editor"));
        this.posKey  = posKey;
        this.block   = block;
        this.pos     = pos;
        this.blockId = class_7923.field_41175.method_10221(block).toString();

        BlockStats existing = StatRegistry.getBlockAt(posKey);
        this.working = existing != null ? existing.copy() : new BlockStats();
    }

    @Override
    protected void method_25426() {
        int panelW = Math.min(340, this.field_22789 - PAD * 2);
        int panelX = (this.field_22789 - panelW) / 2;

        int footerY = this.field_22790 - FOOTER_H - PAD;

        int tabW = panelW / TAB_NAMES.length;
        for (int i = 0; i < TAB_NAMES.length; i++) {
            final int idx = i;
            tabBtns[i] = class_4185.method_46430(class_2561.method_43470(TAB_NAMES[i]), b -> selectTab(idx))
                    .method_46434(panelX + i * tabW, HEADER_H, tabW - 2, TAB_H)
                    .method_46431();
            method_37063(tabBtns[i]);
        }

        int bh = 18;
        int bw1 = 60, bw2 = 50, bw3 = 76, bw4 = 82, bw5 = 50;
        int totalBW = bw1 + bw2 + bw3 + bw4 + bw5 + PAD * 4;
        int bx = (this.field_22789 - totalBW) / 2;
        int by = footerY + (FOOTER_H - bh) / 2;

        applyBtn    = class_4185.method_46430(class_2561.method_43470("Apply"),          b -> doApply())
                .method_46434(bx, by, bw1, bh).method_46431();
        resetBtn    = class_4185.method_46430(class_2561.method_43470("Reset"),          b -> doReset())
                .method_46434(bx + bw1 + PAD, by, bw2, bh).method_46431();
        fromBlockBtn= class_4185.method_46430(class_2561.method_43470("From Block"),     b -> doFromBlock())
                .method_46434(bx + bw1 + bw2 + PAD * 2, by, bw3, bh).method_46431();
        editTypeBtn = class_4185.method_46430(class_2561.method_43470("Edit All Type"),  b -> doEditType())
                .method_46434(bx + bw1 + bw2 + bw3 + PAD * 3, by, bw4, bh).method_46431();
        closeBtn    = class_4185.method_46430(class_2561.method_43470("Close"),          b -> method_25419())
                .method_46434(bx + bw1 + bw2 + bw3 + bw4 + PAD * 4, by, bw5, bh).method_46431();

        method_37063(applyBtn);
        method_37063(resetBtn);
        method_37063(fromBlockBtn);
        method_37063(editTypeBtn);
        method_37063(closeBtn);

        rebuildRows();
    }

    private void selectTab(int tab) {
        activeTab    = tab;
        scrollOffset = 0;
        rebuildRows();
    }

    private void rebuildRows() {
        rows.clear();
        int panelW = Math.min(340, this.field_22789 - PAD * 2);
        int panelX = (this.field_22789 - panelW) / 2;
        List<FieldDef> fields = StatEditorPanel.getBlockFieldsForTab(activeTab);
        int startY = HEADER_H + TAB_H + PAD * 2;
        int curY   = startY;
        for (FieldDef fd : fields) {
            rows.add(FieldRow.create(fd, working, panelX + PAD, curY, panelW - PAD * 2,
                    () -> { unsaved++; updateApplyLabel(); }));
            curY += ROW_H;
        }
    }

    private void updateApplyLabel() {
        if (applyBtn != null)
            applyBtn.method_25355(class_2561.method_43470(unsaved > 0 ? "Apply ●" : "Apply"));
    }

    private void doApply() {
        CraftStatsNetwork.sendApplyBlockPosStats(posKey, working);
        unsaved = 0;
        updateApplyLabel();
    }

    private void doReset() {
        CraftStatsNetwork.sendResetBlockPos(posKey);
        working  = new BlockStats();
        unsaved  = 0;
        scrollOffset = 0;
        rebuildRows();
        updateApplyLabel();
    }

    private void doFromBlock() {
        class_310.method_1551().method_1507(
            new BlockSourceBrowserScreen(this, extracted -> {

                working.hardness       = extracted.hardness;
                working.blastResistance= extracted.blastResistance;
                working.slipperiness   = extracted.slipperiness;
                working.bounceFactor   = extracted.bounceFactor;
                working.noCollision    = extracted.noCollision;
                working.lightEmission  = extracted.lightEmission;
                working.climbable      = extracted.climbable;
                working.stepDamage     = extracted.stepDamage;
                working.speedModifier  = extracted.speedModifier;
                working.freezeOnStep   = extracted.freezeOnStep;
                unsaved++;
                updateApplyLabel();
                rebuildRows();
            })
        );
    }

    private void doEditType() {
        class_310.method_1551().method_1507(new CraftStatsScreen(block));
    }

    @Override
    public void method_25420(class_332 g, int mouseX, int mouseY, float delta) {

    }

    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float delta) {
        int panelW = Math.min(340, this.field_22789 - PAD * 2);
        int panelX = (this.field_22789 - panelW) / 2;
        int panelH = this.field_22790 - HEADER_H - TAB_H - FOOTER_H - PAD * 3;
        int panelY = HEADER_H + TAB_H;
        int footerY = this.field_22790 - FOOTER_H - PAD;

        g.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF0D0D1C);

        g.method_25294(panelX, panelY, panelX + panelW, panelY + panelH, 0xFF16213E);
        drawBorder(g, panelX, panelY, panelX + panelW, panelY + panelH, 0xFF3355AA);

        String typeShort = blockId.contains(":") ? blockId.split(":")[1] : blockId;
        String posStr    = pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260();
        g.method_25300(field_22793, "§b§l" + typeShort, this.field_22789 / 2, PAD + 2, 0xFFFFFFFF);
        g.method_25300(field_22793, "§7Block at " + posStr + " §8(this block only)", this.field_22789 / 2, PAD + 14, 0xFFAAAAAA);
        g.method_25300(field_22793, "§8" + blockId, this.field_22789 / 2, PAD + 24, 0xFF555555);

        g.method_25294(0, footerY, this.field_22789, footerY + FOOTER_H + PAD, 0xFF0F3460);
        drawBorder(g, 0, footerY, this.field_22789, footerY + FOOTER_H + PAD, 0xFF3355AA);

        int tabW = panelW / TAB_NAMES.length;
        int tx   = panelX + activeTab * tabW;
        g.method_25294(tx, HEADER_H, tx + tabW - 2, HEADER_H + TAB_H, 0xFF2244AA);
        g.method_25294(tx, HEADER_H + TAB_H - 2, tx + tabW - 2, HEADER_H + TAB_H, 0xFF5588FF);

        int bodyY   = panelY + PAD;
        int bodyBot = panelY + panelH - PAD;

        for (FieldRow row : rows) {
            int screenRowY = row.y - scrollOffset;
            if (screenRowY + ROW_H < bodyY || screenRowY > bodyBot) continue;
            row.render(g, mouseX, mouseY + scrollOffset, delta, scrollOffset);
        }

        super.method_25394(g, mouseX, mouseY, delta);

        if (unsaved > 0) {
            g.method_51433(field_22793, "§e" + unsaved + " unsaved change(s)", PAD, footerY + 6, 0xFFFFEEAA, false);
        }
    }

    private static void drawBorder(class_332 g, int x1, int y1, int x2, int y2, int color) {
        g.method_25294(x1,     y1,     x2,     y1 + 1, color);
        g.method_25294(x1,     y2 - 1, x2,     y2,     color);
        g.method_25294(x1,     y1,     x1 + 1, y2,     color);
        g.method_25294(x2 - 1, y1,     x2,     y2,     color);
    }

    @Override
    public boolean method_25402(double mx, double my, int btn) {
        for (FieldRow row : rows) {
            if (row.mouseClicked(mx, my + scrollOffset, btn)) return true;
        }
        return super.method_25402(mx, my, btn);
    }

    @Override
    public boolean method_25401(double mx, double my, double hScroll, double vScroll) {
        int panelH     = this.field_22790 - HEADER_H - TAB_H - FOOTER_H - PAD * 3;
        int totalRowsH = rows.size() * ROW_H;
        int maxScroll  = Math.max(0, totalRowsH - panelH + PAD * 4);
        scrollOffset   = (int) Math.max(0, Math.min(maxScroll, scrollOffset - vScroll * ROW_H));
        return true;
    }

    @Override
    public boolean method_25404(int key, int scan, int mods) {
        for (FieldRow row : rows) {
            if (row.keyPressed(key, scan, mods)) return true;
        }
        return super.method_25404(key, scan, mods);
    }

    @Override
    public boolean method_25400(char c, int mods) {
        for (FieldRow row : rows) {
            if (row.charTyped(c, mods)) return true;
        }
        return super.method_25400(c, mods);
    }

    @Override
    public boolean method_25421() { return false; }
}
