package com.craftstats.common.mixin;

import com.craftstats.common.stats.BlockStats;
import com.craftstats.common.stats.MobStats;
import com.craftstats.common.stats.PlayerStats;
import com.craftstats.common.stats.StatRegistry;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import net.minecraft.class_8103;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    @Inject(method = "getMaxHealth", at = @At("HEAD"), cancellable = true)
    private void craftstats$getMaxHealth(CallbackInfoReturnable<Float> cir) {
        class_1309 self = (class_1309)(Object)this;
        if (self instanceof class_1657 player) {
            PlayerStats ps = StatRegistry.getPlayer(player.method_5667());
            if (ps != null) { cir.setReturnValue((float) ps.maxHealth); return; }
        }
        MobStats uuidStats = StatRegistry.getMobUuid(self.method_5667());
        if (uuidStats != null && uuidStats.maxHealth >= 0) { cir.setReturnValue((float) uuidStats.maxHealth); return; }
        class_2960 typeId = class_1299.method_5890(self.method_5864());
        if (typeId == null) return;
        MobStats stats = StatRegistry.getMob(typeId);
        if (stats != null && stats.maxHealth >= 0) cir.setReturnValue((float) stats.maxHealth);
    }

    @Inject(method = "causeFallDamage", at = @At("HEAD"), cancellable = true)
    private void craftstats$fallImmune(float dist, float mul,
                                        class_1282 src,
                                        CallbackInfoReturnable<Boolean> cir) {
        class_1309 self = (class_1309)(Object)this;
        if (self instanceof class_1657 player) {
            PlayerStats ps = StatRegistry.getPlayer(player.method_5667());
            if (ps != null && ps.noFallDamage) { cir.setReturnValue(false); return; }
        }
        MobStats ms = StatRegistry.getMobUuid(self.method_5667());
        if (ms == null) {
            class_2960 typeId = class_1299.method_5890(self.method_5864());
            if (typeId == null) return;
            ms = StatRegistry.getMob(typeId);
        }
        if (ms != null && ms.immuneFall) cir.setReturnValue(false);
    }

    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    private void craftstats$hurt(class_1282 src, float amount,
                                  CallbackInfoReturnable<Boolean> cir) {
        class_1309 self = (class_1309)(Object)this;

        if (self instanceof class_1657 player) {
            PlayerStats ps = StatRegistry.getPlayer(player.method_5667());
            if (ps == null) return;
            if (ps.godMode)   { cir.setReturnValue(false); return; }
            if (ps.drownImmune && isDrown(src))                          { cir.setReturnValue(false); return; }
            if (ps.fireImmune  && src.method_48789(class_8103.field_42246))        { cir.setReturnValue(false); return; }
            if (ps.noPoison    && isMagic(src))                          { cir.setReturnValue(false); return; }
            if (ps.noMagic     && src.method_48789(class_8103.field_42241)
                    && !src.method_48789(class_8103.field_42242)) { cir.setReturnValue(false); return; }
        } else {
            MobStats ms = StatRegistry.getMobUuid(self.method_5667());
            if (ms == null) {
                class_2960 typeId = class_1299.method_5890(self.method_5864());
                if (typeId == null) return;
                ms = StatRegistry.getMob(typeId);
            }
            if (ms == null) return;
            if (ms.invincible)                                           { cir.setReturnValue(false); return; }
            if (ms.immuneDrown     && isDrown(src))                      { cir.setReturnValue(false); return; }
            if (ms.immuneExplosion && src.method_48789(class_8103.field_42249)){ cir.setReturnValue(false); return; }
            if (ms.immunePoison    && isMagic(src))                      { cir.setReturnValue(false); return; }
            if (ms.immuneMagic     && src.method_48789(class_8103.field_42241)
                    && !src.method_48789(class_8103.field_42242)) { cir.setReturnValue(false); return; }
        }
    }

    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void craftstats$stepOnEffects(CallbackInfo ci) {
        class_1309 self = (class_1309)(Object)this;
        if (self.method_37908().field_9236) return;

        if (!(self instanceof class_1657)) {
            class_2960 typeId = class_1299.method_5890(self.method_5864());
            if (typeId != null) {
                MobStats ms = StatRegistry.getMobUuid(self.method_5667());
                if (ms == null) ms = StatRegistry.getMob(typeId);
                if (ms != null) {
                    self.method_5803(ms.silent);
                    self.method_5834(ms.glowing);
                    if (ms.invincible && self instanceof class_1308 mob) {
                        if (mob.field_6008 < 10) mob.field_6008 = 10;
                    }

                    if (ms.burnsDaylight && self.field_6012 % 40 == 0
                            && !self.method_5809() && !self.method_5816()) {
                        if (self.method_37908().method_8530()
                                && !self.method_37908().method_8419()
                                && self.method_37908().method_8311(self.method_24515())) {
                            self.method_5639(8);
                        }
                    }
                }
            }
        }

        if (!self.method_24828()) return;
        class_2338 below = self.method_24515().method_10074();
        BlockStats bs  = resolveBlockStats(self, below);
        if (bs == null) return;

        class_1282 generic = self.method_48923().method_48830();

        if (bs.stepDamage > 0 && self.field_6012 % 10 == 0)
            self.method_5643(generic, bs.stepDamage);

        if (bs.speedModifier != 1.0f && bs.speedModifier > 0) {
            int amplifier = Math.round(bs.speedModifier * 10) - 10;
            if (amplifier >= 0) {
                self.method_6092(new class_1293(class_1294.field_5904, 25, amplifier, false, false));
            } else {
                self.method_6092(new class_1293(class_1294.field_5909, 25, -amplifier - 1, false, false));
            }
        }

        if (bs.levitate)
            self.method_6092(new class_1293(class_1294.field_5902, 25, 0, false, false));

        if (bs.glowOnStep)
            self.method_6092(new class_1293(class_1294.field_5912, 60, 0, false, false));

        if (bs.freezeOnStep) {
            self.method_6092(new class_1293(class_1294.field_5909, 25, 9, false, false));
            self.method_32317(Math.min(self.method_32312() + 3, self.method_32315()));
        }

        if (!bs.onStepPotion.isEmpty()) {
            try {
                class_2960 potionId = class_2960.method_60654(bs.onStepPotion);
                class_7923.field_41174.method_55841(potionId).ifPresent(holder -> {
                    int dur = Math.max(25, bs.onStepPotionDuration + 20);
                    int amp = Math.max(0, bs.onStepPotionLevel - 1);
                    if (!self.method_6059(holder) || self.method_6112(holder).method_5584() < 20)
                        self.method_6092(new class_1293(holder, dur, amp, false, false));
                });
            } catch (Exception ignored) {}
        }
    }

    private static BlockStats resolveBlockStats(class_1309 entity, class_2338 pos) {

        if (entity.method_37908() instanceof class_1937 lv) {
            String posKey = StatRegistry.makePosKey(lv.method_27983(), pos);
            BlockStats ps = StatRegistry.getBlockAt(posKey);
            if (ps != null) return ps;
        }
        class_2960 blockId = class_7923.field_41175
                .method_10221(entity.method_37908().method_8320(pos).method_26204());
        return StatRegistry.getBlock(blockId);
    }

    @Inject(method = "getExperienceReward", at = @At("HEAD"), cancellable = true, require = 0)
    private void craftstats$xpReward(class_3218 level, class_1297 killer,
                                      CallbackInfoReturnable<Integer> cir) {
        class_1309 self = (class_1309)(Object)this;
        if (self instanceof class_1657) return;
        MobStats ms = StatRegistry.getMobUuid(self.method_5667());
        if (ms == null) {
            class_2960 typeId = class_1299.method_5890(self.method_5864());
            if (typeId == null) return;
            ms = StatRegistry.getMob(typeId);
        }
        if (ms != null && ms.xpReward > 0) cir.setReturnValue(ms.xpReward);
    }

    @Inject(method = "dropAllDeathLoot", at = @At("HEAD"), cancellable = true, require = 0)
    private void craftstats$keepInventory(class_3218 level, class_1282 source, CallbackInfo ci) {
        class_1309 self = (class_1309)(Object)this;
        if (!(self instanceof class_1657)) return;
        PlayerStats ps = StatRegistry.getPlayer(((class_1657) self).method_5667());
        if (ps != null && ps.keepInventory) ci.cancel();
    }

    @Inject(method = "onClimbable", at = @At("HEAD"), cancellable = true, require = 0)
    private void craftstats$climbable(CallbackInfoReturnable<Boolean> cir) {
        class_1309 self = (class_1309)(Object)this;
        class_2338 pos = self.method_24515();

        if (self.method_37908() instanceof class_1937 lv) {
            String posKey = StatRegistry.makePosKey(lv.method_27983(), pos);
            BlockStats ps = StatRegistry.getBlockAt(posKey);
            if (ps != null && ps.climbable) { cir.setReturnValue(true); return; }
        }

        class_2960 blockId = class_7923.field_41175.method_10221(
                self.method_37908().method_8320(pos).method_26204());
        BlockStats stats = StatRegistry.getBlock(blockId);
        if (stats != null && stats.climbable) cir.setReturnValue(true);
    }

    private static boolean isDrown(class_1282 src) {
        return "drown".equals(src.method_48792().comp_1242());
    }

    private static boolean isMagic(class_1282 src) {
        return "magic".equals(src.method_48792().comp_1242());
    }
}
