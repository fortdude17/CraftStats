package com.craftstats.common.gui;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class StatResetScreen extends class_437 {

    private static final int ROW_H   = 22;
    private static final int PAD     = 6;
    private static final int HEADER_H = 50;
    private static final int FOOTER_H = 30;

    private final class_437 parent;

    record WorldEntry(String worldName, Path statsFile, int entryCount) {}
    private final List<WorldEntry> entries = new ArrayList<>();
    private int selectedIndex = -1;
    private int msgTimer      = 0;
    private String lastMsg    = "";

    private class_4185 deleteSelectedBtn, deleteAllBtn, closeBtn;

    public StatResetScreen(class_437 parent) {
        super(class_2561.method_43470("CraftStats — Emergency Reset"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        scanWorlds();

        int bh = 18;
        int bw1 = 200, bw2 = 180, bw3 = 60;
        int totalW = bw1 + bw2 + bw3 + PAD * 2;
        int bx = (this.field_22789 - totalW) / 2;
        int by = this.field_22790 - FOOTER_H - PAD + (FOOTER_H - bh) / 2;

        deleteSelectedBtn = class_4185.method_46430(class_2561.method_43470("Delete Selected World's Stats"),
                b -> deleteSelected())
                .method_46434(bx, by, bw1, bh).method_46431();
        deleteAllBtn = class_4185.method_46430(class_2561.method_43470("Delete ALL Worlds' Stats"),
                b -> deleteAll())
                .method_46434(bx + bw1 + PAD, by, bw2, bh).method_46431();
        closeBtn = class_4185.method_46430(class_2561.method_43470("Close"),
                b -> class_310.method_1551().method_1507(parent))
                .method_46434(bx + bw1 + bw2 + PAD * 2, by, bw3, bh).method_46431();

        method_37063(deleteSelectedBtn);
        method_37063(deleteAllBtn);
        method_37063(closeBtn);
        refreshButtonState();
    }

    private void scanWorlds() {
        entries.clear();
        try {
            Path savesDir = class_310.method_1551().field_1697.toPath().resolve("saves");
            if (!Files.exists(savesDir)) return;
            try (var stream = Files.list(savesDir)) {
                stream.filter(Files::isDirectory).forEach(worldDir -> {
                    Path statsFile = worldDir.resolve("craftstats").resolve("stats.json");
                    if (Files.exists(statsFile))
                        entries.add(new WorldEntry(
                                worldDir.getFileName().toString(), statsFile, countEntries(statsFile)));
                });
            }
            entries.sort(Comparator.comparing(WorldEntry::worldName));
        } catch (Exception ignored) {}
        if (selectedIndex >= entries.size()) selectedIndex = entries.size() - 1;
        refreshButtonState();
    }

    private int countEntries(Path statsFile) {
        try {
            var root = JsonParser.parseString(Files.readString(statsFile)).getAsJsonObject();
            int n = 0;
            for (String key : new String[]{"mobs","blocks","items","players","block_positions"})
                if (root.has(key)) n += root.getAsJsonObject(key).size();
            return n;
        } catch (Exception e) { return 0; }
    }

    private void deleteSelected() {
        if (selectedIndex < 0 || selectedIndex >= entries.size()) return;
        WorldEntry e = entries.get(selectedIndex);
        try {
            Files.deleteIfExists(e.statsFile());
            flash("§aDeleted stats for '" + e.worldName() + "'.");
        } catch (IOException ex) {
            flash("§cError: " + ex.getMessage());
        }
        scanWorlds();
    }

    private void deleteAll() {
        int count = 0;
        for (WorldEntry e : new ArrayList<>(entries)) {
            try { Files.deleteIfExists(e.statsFile()); count++; }
            catch (IOException ignored) {}
        }
        flash("§aCleared stats for " + count + " world(s).");
        selectedIndex = -1;
        scanWorlds();
    }

    private void flash(String msg) { lastMsg = msg; msgTimer = 100; }

    private void refreshButtonState() {
        if (deleteSelectedBtn != null)
            deleteSelectedBtn.field_22763 = selectedIndex >= 0 && selectedIndex < entries.size();
        if (deleteAllBtn != null)
            deleteAllBtn.field_22763 = !entries.isEmpty();
    }

    @Override public void method_25393() { if (msgTimer > 0) msgTimer--; }

    @Override
    public void method_25420(class_332 g, int mx, int my, float delta) {}

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        int listX   = PAD * 2;
        int listY   = HEADER_H + PAD;
        int footerY = this.field_22790 - FOOTER_H - PAD;
        int listH   = footerY - listY - PAD;
        int listW   = this.field_22789 - PAD * 4;

        g.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF0D0D1C);

        g.method_25294(0, 0, this.field_22789, HEADER_H, 0xFF0F3460);
        drawBorder(g, 0, 0, this.field_22789, HEADER_H, 0xFF3355AA);
        g.method_25300(field_22793, "§b§lCraftStats — Emergency Reset", this.field_22789 / 2, 10, 0xFFFFFFFF);
        g.method_25300(field_22793, "§7Delete mod data before loading a world to fix crashes / unplayable states",
                this.field_22789 / 2, 24, 0xFFAAAAAA);
        g.method_25300(field_22793, "§8Click a row to select, then use the buttons below",
                this.field_22789 / 2, 36, 0xFF555555);

        g.method_25294(listX, listY, listX + listW, listY + listH, 0xFF16213E);
        drawBorder(g, listX, listY, listX + listW, listY + listH, 0xFF3355AA);

        if (entries.isEmpty()) {
            g.method_25300(field_22793, "§7No CraftStats data found in any world save.",
                    this.field_22789 / 2, listY + listH / 2 - 4, 0xFF666666);
            g.method_25300(field_22793, "§8(All saves are clean — no mod data to remove)",
                    this.field_22789 / 2, listY + listH / 2 + 10, 0xFF444444);
        } else {
            int rowY = listY + PAD;
            for (int i = 0; i < entries.size(); i++) {
                WorldEntry e = entries.get(i);
                boolean sel = i == selectedIndex;
                boolean hov = mx >= listX && mx < listX + listW && my >= rowY && my < rowY + ROW_H;
                if (sel)      g.method_25294(listX + 1, rowY, listX + listW - 1, rowY + ROW_H, 0xFF1E3A8A);
                else if (hov) g.method_25294(listX + 1, rowY, listX + listW - 1, rowY + ROW_H, 0xFF1A2A50);
                String name = e.worldName().length() > 40 ? e.worldName().substring(0,39) + "…" : e.worldName();
                String info = e.entryCount() + " custom entr" + (e.entryCount() == 1 ? "y" : "ies");
                g.method_51433(field_22793, (sel ? "§e▶ §f" : "§7  §f") + name, listX + 6, rowY + (ROW_H - 8) / 2, 0xFFFFFFFF, false);
                g.method_51433(field_22793, "§7" + info, listX + listW - field_22793.method_1727(info) - 8, rowY + (ROW_H - 8) / 2, 0xFFAAAAAA, false);
                if (i < entries.size() - 1)
                    g.method_25294(listX + 4, rowY + ROW_H - 1, listX + listW - 4, rowY + ROW_H, 0xFF222244);
                rowY += ROW_H;
            }
        }

        g.method_25294(0, footerY, this.field_22789, this.field_22790, 0xFF0F3460);
        drawBorder(g, 0, footerY, this.field_22789, this.field_22790, 0xFF3355AA);
        if (msgTimer > 0)
            g.method_25300(field_22793, lastMsg, this.field_22789 / 2, footerY - 14, 0xFFFFFFFF);

        super.method_25394(g, mx, my, delta);
    }

    @Override
    public boolean method_25402(double mx, double my, int btn) {
        if (super.method_25402(mx, my, btn)) return true;
        int listX   = PAD * 2;
        int listY   = HEADER_H + PAD;
        int footerY = this.field_22790 - FOOTER_H - PAD;
        int listW   = this.field_22789 - PAD * 4;
        int listH   = footerY - listY - PAD;
        if (mx >= listX && mx < listX + listW && my >= listY && my < listY + listH) {
            int idx = ((int)(my - listY) - PAD) / ROW_H;
            if (idx >= 0 && idx < entries.size()) {
                selectedIndex = idx;
                refreshButtonState();
                return true;
            }
        }
        return false;
    }

    private static void drawBorder(class_332 g, int x1, int y1, int x2, int y2, int c) {
        g.method_25294(x1, y1, x2, y1 + 1, c); g.method_25294(x1, y2 - 1, x2, y2, c);
        g.method_25294(x1, y1, x1 + 1, y2, c); g.method_25294(x2 - 1, y1, x2, y2, c);
    }

    @Override public boolean method_25421() { return false; }
}
