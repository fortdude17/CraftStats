package com.craftstats.fabric;

import com.craftstats.common.CraftStatsClient;
import com.craftstats.common.gui.BlockPosScreen;
import com.craftstats.common.gui.CraftStatsScreen;
import com.craftstats.common.gui.RandomizeScreen;
import com.craftstats.common.stats.MobStats;
import com.craftstats.common.stats.StatRegistry;
import com.craftstats.common.stats.TargetType;
import com.craftstats.common.util.ScreenOpener;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;

public class CraftStatsClientFabric implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        CraftStatsClient.init();
        registerScreenOpener();
    }

    private void registerScreenOpener() {
        ScreenOpener.setImpl(new ScreenOpener.Impl() {
            @Override
            public void openBlockEditor(class_2248 block) {
                class_310.method_1551().method_1507(new CraftStatsScreen(block));
            }

            @Override
            public void openBlockEditorAt(String posKey, class_2248 block, class_2338 pos) {
                class_310.method_1551().method_1507(new BlockPosScreen(posKey, block, pos));
            }

            @Override
            public void openMobEditor(class_1309 entity) {
                class_310.method_1551().method_1507(new CraftStatsScreen(entity));
            }

            @Override
            public void openMobEditorById(String entityTypeId) {
                class_310.method_1551().method_1507(
                        new CraftStatsScreen(com.craftstats.common.stats.TargetType.MOB, entityTypeId));
            }

            @Override
            public void openItemEditor(String itemId) {
                CraftStatsScreen screen = new CraftStatsScreen();
                class_310.method_1551().method_1507(screen);
                screen.selectItemById(itemId);
            }

            @Override
            public void openPlayerEditor(class_1657 player) {
                class_310.method_1551().method_1507(
                        new com.craftstats.common.gui.PlayerStatsScreen(
                                player.method_5667(), player.method_5477().getString()));
            }

            @Override
            public void openRandomizeBlock(class_2248 block) {
                String id = class_7923.field_41175.method_10221(block).toString();
                com.craftstats.common.stats.BlockStats stats = StatRegistry.getBlock(class_2960.method_60654(id));
                if (stats == null) stats = new com.craftstats.common.stats.BlockStats();
                class_310.method_1551().method_1507(new RandomizeScreen(TargetType.BLOCK, id, stats));
            }

            @Override
            public void openRandomizeMob(class_1309 entity) {
                String id = class_1299.method_5890(entity.method_5864()).toString();
                MobStats stats = StatRegistry.getMob(class_2960.method_60654(id));
                if (stats == null) stats = new MobStats();
                class_310.method_1551().method_1507(new RandomizeScreen(TargetType.MOB, id, stats));
            }
        });
    }
}
