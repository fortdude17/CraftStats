package com.craftstats.fabric.config;

import com.craftstats.common.config.CraftStatsConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class CraftStatsConfigScreen extends class_437 {

    private final class_437 parent;
    private CraftStatsConfig.ConfigData cfg;

    private class_342 intensityBox;
    private class_4185  requireOpBtn, allowSurvivalBtn, saveBtn, cancelBtn;

    public CraftStatsConfigScreen(class_437 parent) {
        super(class_2561.method_43470("CraftStats Config"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        cfg = CraftStatsConfig.get();
        int cx = this.field_22789 / 2;
        int rowY = 40;
        int bw = 160, bh = 16;

        requireOpBtn = class_4185.method_46430(
                class_2561.method_43470("Require OP: " + cfg.requireOp),
                b -> { cfg.requireOp = !cfg.requireOp;
                    b.method_25355(class_2561.method_43470("Require OP: " + cfg.requireOp)); })
                .method_46434(cx - bw / 2, rowY, bw, bh).method_46431();
        rowY += 22;

        allowSurvivalBtn = class_4185.method_46430(
                class_2561.method_43470("Allow Survival: " + cfg.allowSurvival),
                b -> { cfg.allowSurvival = !cfg.allowSurvival;
                    b.method_25355(class_2561.method_43470("Allow Survival: " + cfg.allowSurvival)); })
                .method_46434(cx - bw / 2, rowY, bw, bh).method_46431();
        rowY += 22;

        intensityBox = new class_342(this.field_22793, cx - 60, rowY, 120, bh,
                class_2561.method_43470("Intensity"));
        intensityBox.method_1852(cfg.randomizeIntensity);
        rowY += 22;

        saveBtn = class_4185.method_46430(class_2561.method_43470("Save"),
                b -> { cfg.randomizeIntensity = intensityBox.method_1882();
                    CraftStatsConfig.save(); method_25419(); })
                .method_46434(cx - 40, rowY + 10, 80, bh).method_46431();
        cancelBtn = class_4185.method_46430(class_2561.method_43470("Cancel"), b -> method_25419())
                .method_46434(cx - 40, rowY + 32, 80, bh).method_46431();

        method_37063(requireOpBtn);
        method_37063(allowSurvivalBtn);
        method_37063(intensityBox);
        method_37063(saveBtn);
        method_37063(cancelBtn);
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        this.method_25420(g, mx, my, delta);
        g.method_25300(this.field_22793, "CraftStats Config", this.field_22789 / 2, 14, 0xFFFFFFFF);
        g.method_51433(this.field_22793, "Randomize Intensity:", this.field_22789 / 2 - 60, 85, 0xFFCCCCCC, false);
        super.method_25394(g, mx, my, delta);
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(parent);
    }
}
