package com.craftstats.common.gui;

import com.craftstats.common.network.CraftStatsNetwork;
import com.craftstats.common.preset.Preset;
import com.craftstats.common.preset.PresetManager;
import com.craftstats.common.randomize.RandomizeManager;
import com.craftstats.common.stats.*;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class RandomizeScreen extends class_437 {

    private final TargetType type;
    private final String     targetId;
    private final Object     vanilla;

    private Object randomized;
    private long   currentSeed;

    private class_342 seedBox;
    private class_4185  rerollBtn, confirmBtn, rerollAllBtn, savePresetBtn, cancelBtn;

    private static final int COL_W = 160;
    private static final int ROW_H = 12;
    private static final int PAD   = 6;

    public RandomizeScreen(TargetType type, String targetId, Object vanillaStats) {
        super(class_2561.method_43470("Randomize - " + targetId));
        this.type      = type;
        this.targetId  = targetId;
        this.vanilla   = vanillaStats;
        this.currentSeed = RandomizeManager.newSeed();
        reroll();
    }

    private void reroll() {
        currentSeed = RandomizeManager.newSeed();
        randomized  = randomizeWith(currentSeed);
    }

    private Object randomizeWith(long seed) {
        return switch (type) {
            case MOB    -> RandomizeManager.randomizeMob((MobStats) vanilla, seed);
            case BLOCK  -> RandomizeManager.randomizeBlock((BlockStats) vanilla, seed);
            case ITEM   -> RandomizeManager.randomizeItem((ItemStats) vanilla, seed);
            case PLAYER -> RandomizeManager.randomizePlayer((PlayerStats) vanilla, seed);
        };
    }

    @Override
    protected void method_25426() {
        int bw = 70, bh = 16;
        int cx = this.field_22789 / 2;
        int bottomY = this.field_22790 - bh - PAD * 2;

        seedBox = new class_342(this.field_22793, cx - 60, bottomY - bh - PAD * 2, 120, bh,
                class_2561.method_43470("Seed"));
        seedBox.method_1880(20);
        seedBox.method_1852(String.valueOf(currentSeed));
        seedBox.method_1863(v -> {
            try { currentSeed = Long.parseLong(v); randomized = randomizeWith(currentSeed); }
            catch (NumberFormatException ignored) {}
        });

        rerollBtn    = class_4185.method_46430(class_2561.method_43470("Reroll All"),  b -> { reroll(); seedBox.method_1852(String.valueOf(currentSeed)); })
                .method_46434(cx - bw - PAD, bottomY, bw, bh).method_46431();
        confirmBtn   = class_4185.method_46430(class_2561.method_43470("Confirm"),     b -> apply())
                .method_46434(cx + PAD, bottomY, bw, bh).method_46431();
        cancelBtn    = class_4185.method_46430(class_2561.method_43470("Cancel"),      b -> method_25419())
                .method_46434(PAD, bottomY, 50, bh).method_46431();
        savePresetBtn= class_4185.method_46430(class_2561.method_43470("Save Preset"), b -> saveAsPreset())
                .method_46434(this.field_22789 - 90 - PAD, bottomY, 90, bh).method_46431();

        method_37063(seedBox);
        method_37063(rerollBtn);
        method_37063(confirmBtn);
        method_37063(cancelBtn);
        method_37063(savePresetBtn);
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        this.method_25420(g, mx, my, delta);
        g.method_25294(0, 0, this.field_22789, this.field_22790, 0xCC000000);

        g.method_25300(this.field_22793, "Randomize Preview — " + type.name() + " " + targetId,
                this.field_22789 / 2, PAD, 0xFFFFFFFF);
        g.method_25300(this.field_22793, "Seed: " + currentSeed,
                this.field_22789 / 2, PAD + 12, 0xFFAAAAAA);

        int startY = PAD + 28;
        int leftX  = PAD + 20;
        int rightX = this.field_22789 / 2 + PAD;
        g.method_51433(this.field_22793, "ORIGINAL",   leftX,  startY, 0xFF888888, false);
        g.method_51433(this.field_22793, "RANDOMIZED", rightX, startY, 0xFF44BB44, false);

        if (vanilla != null && randomized != null) {
            renderDiff(g, vanilla, randomized, leftX, rightX, startY + 14);
        }

        super.method_25394(g, mx, my, delta);
    }

    private void renderDiff(class_332 g, Object orig, Object rand, int leftX, int rightX, int startY) {
        java.lang.reflect.Field[] fields = orig.getClass().getFields();
        int rowY = startY;
        int bodyH = this.field_22790 - startY - 60;
        for (java.lang.reflect.Field f : fields) {
            if (rowY - startY > bodyH) break;
            f.setAccessible(true);
            try {
                Object ov = f.get(orig);
                Object rv = f.get(rand);
                if (ov == null || rv == null) continue;
                boolean changed = !ov.toString().equals(rv.toString());
                int color = changed ? 0xFFFFAA44 : 0xFF888888;
                String label = f.getName();
                String oval  = formatVal(ov);
                String rval  = formatVal(rv);
                g.method_51433(this.field_22793, label + ": " + oval, leftX,  rowY, color, false);
                g.method_51433(this.field_22793, rval,                rightX, rowY, changed ? 0xFF44FF44 : 0xFF888888, false);
                rowY += ROW_H;
            } catch (Exception ignored) {}
        }
    }

    private String formatVal(Object v) {
        if (v instanceof Double d)  return String.format("%.4f", d).replaceAll("0+$","").replaceAll("\\.$","");
        if (v instanceof Float  f)  return String.format("%.4f", f).replaceAll("0+$","").replaceAll("\\.$","");
        return String.valueOf(v);
    }

    private void apply() {
        switch (type) {
            case MOB    -> CraftStatsNetwork.sendApplyMobStats(targetId, (MobStats) randomized);
            case BLOCK  -> CraftStatsNetwork.sendApplyBlockStats(targetId, (BlockStats) randomized);
            case ITEM   -> CraftStatsNetwork.sendApplyItemStats(targetId, (ItemStats) randomized);
            case PLAYER -> CraftStatsNetwork.sendApplyPlayerStats(UUID.fromString(targetId), (PlayerStats) randomized);
        }
        method_25419();
    }

    private void saveAsPreset() {
        String name = "rand_" + type.name().toLowerCase() + "_" + currentSeed;
        Preset p = new Preset(name, type, randomized);
        p.seed = currentSeed;
        PresetManager.savePreset(p);
        class_310.method_1551().field_1724.method_43496(
                net.minecraft.class_2561.method_43470("Saved preset: " + name));
    }

    @Override
    public boolean method_25421() { return false; }
}
