package com.craftstats.common.mixin;

import com.craftstats.common.stats.ItemStats;
import com.craftstats.common.stats.StatRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public abstract class ItemMixin {

    @Inject(method = "getMaxStackSize", at = @At("HEAD"), cancellable = true)
    private void craftstats$stackSize(CallbackInfoReturnable<Integer> cir) {
        class_1799 self = (class_1799) (Object) this;
        class_2960 id = class_7923.field_41178.method_10221(self.method_7909());
        ItemStats stats = StatRegistry.getItem(id);
        if (stats != null) cir.setReturnValue(stats.stackSize);
    }

    @Inject(method = "getMaxDamage", at = @At("HEAD"), cancellable = true)
    private void craftstats$maxDurability(CallbackInfoReturnable<Integer> cir) {
        class_1799 self = (class_1799) (Object) this;
        class_2960 id = class_7923.field_41178.method_10221(self.method_7909());
        ItemStats stats = StatRegistry.getItem(id);
        if (stats != null && stats.maxDurability > 0) cir.setReturnValue(stats.maxDurability);
    }
}
