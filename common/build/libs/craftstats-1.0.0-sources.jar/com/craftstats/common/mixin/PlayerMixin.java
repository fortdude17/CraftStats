package com.craftstats.common.mixin;

import com.craftstats.common.stats.PlayerStats;
import com.craftstats.common.stats.StatRegistry;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1657.class)
public abstract class PlayerMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void craftstats$tick(CallbackInfo ci) {
        class_1657 self = (class_1657)(Object)this;
        if (self.method_37908().method_8608()) return;
        PlayerStats ps = StatRegistry.getPlayer(self.method_5667());
        self.field_5960 = (ps != null && ps.noClip);
        if (ps == null) return;

        if (self.field_6012 % 60 == 0) craftstats$applyPermanentEffects(self, ps);
    }

    private static void craftstats$applyPermanentEffects(class_1657 self, PlayerStats ps) {
        int dur = 200;
        if (ps.fxNightVision)  craftstats$grant(self, class_1294.field_5925,   dur, 0);
        if (ps.fxWaterBreath)  craftstats$grant(self, class_1294.field_5923, dur, 0);
        if (ps.fxFireResist)   craftstats$grant(self, class_1294.field_5918, dur, 0);
        if (ps.fxRegen)        craftstats$grant(self, class_1294.field_5924,    dur, 0);
        if (ps.fxGlowing)      craftstats$grant(self, class_1294.field_5912,         dur, 0);
        if (ps.fxInvisibility) craftstats$grant(self, class_1294.field_5905,    dur, 0);
        if (ps.fxHaste > 0)    craftstats$grant(self, class_1294.field_5917,       dur, ps.fxHaste - 1);
        if (ps.fxStrength > 0) craftstats$grant(self, class_1294.field_5910,    dur, ps.fxStrength - 1);
        if (ps.fxSpeed > 0)    craftstats$grant(self, class_1294.field_5904,  dur, ps.fxSpeed - 1);
    }

    private static void craftstats$grant(class_1309 entity,
            net.minecraft.class_6880<net.minecraft.class_1291> effect,
            int duration, int amp) {
        var existing = entity.method_6112(effect);

        if (existing == null || existing.method_5584() < 80)
            entity.method_6092(new class_1293(effect, duration, amp, true, false));
    }

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void craftstats$oneHitKill(class_1297 target, CallbackInfo ci) {
        class_1657 self = (class_1657)(Object)this;
        PlayerStats ps = StatRegistry.getPlayer(self.method_5667());
        if (ps == null || !ps.oneHitKill) return;
        target.method_5643(self.method_48923().method_48802(self), 9_999f);
        ci.cancel();
    }

    @ModifyConstant(method = "attack", constant = @Constant(floatValue = 1.5f), require = 0)
    private float craftstats$critMultiplier(float vanilla) {
        class_1657 self = (class_1657)(Object)this;
        PlayerStats ps = StatRegistry.getPlayer(self.method_5667());
        return (ps != null) ? (float) ps.critMultiplier : vanilla;
    }

    @ModifyVariable(method = "giveExperiencePoints", at = @At("HEAD"), argsOnly = true, require = 0)
    private int craftstats$xpMultiplier(int amount) {
        class_1657 self = (class_1657)(Object)this;
        PlayerStats ps = StatRegistry.getPlayer(self.method_5667());
        if (ps != null && ps.xpMultiplier != 1.0) return (int)(amount * ps.xpMultiplier);
        return amount;
    }

}
