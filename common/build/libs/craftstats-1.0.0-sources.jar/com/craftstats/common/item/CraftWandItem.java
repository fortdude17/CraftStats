package com.craftstats.common.item;

import com.craftstats.common.config.CraftStatsConfig;
import com.craftstats.common.stats.BlockStats;
import com.craftstats.common.stats.MobStats;
import com.craftstats.common.stats.StatRegistry;
import com.craftstats.common.util.JsonUtil;
import com.craftstats.common.util.ScreenOpener;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_7923;

public class CraftWandItem extends class_1792 {

    public CraftWandItem(class_1793 props) {
        super(props);
    }

    @Override
    public class_1269 method_7884(class_1838 ctx) {
        class_1937  level  = ctx.method_8045();
        class_1657 player = ctx.method_8036();
        if (player == null) return class_1269.field_5811;
        if (!canUse(player)) {
            if (level.field_9236)
                player.method_43496(class_2561.method_43470("CraftStats: requires operator or creative mode.")
                        .method_27692(class_124.field_1061));
            return class_1269.field_5814;
        }
        if (level.field_9236) {
            net.minecraft.class_2338 clickedPos = ctx.method_8037();
            class_2248 block = level.method_8320(clickedPos).method_26204();
            if (player.method_5715()) {

                ScreenOpener.openBlockEditor(block);
            } else {

                String posKey = StatRegistry.makePosKey(level.method_27983(), clickedPos);
                ScreenOpener.openBlockEditorAt(posKey, block, clickedPos);
            }
        }
        return class_1269.method_29236(level.field_9236);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (hand != class_1268.field_5808)
            return class_1271.method_22430(player.method_5998(hand));
        if (!canUse(player))
            return class_1271.method_22430(player.method_5998(hand));

        if (level.field_9236) {

            class_1799 offhand = player.method_5998(class_1268.field_5810);
            if (offhand.method_7909() instanceof class_1826) {
                String typeId = spawnEggEntityTypeId(offhand);
                if (typeId != null) {
                    ScreenOpener.openMobEditorById(typeId);
                    return class_1271.method_29237(player.method_5998(hand), true);
                }
            }

            ScreenOpener.openPlayerEditor(player);
        }
        return class_1271.method_29237(player.method_5998(hand), level.field_9236);
    }

    @Override
    public class_1269 method_7847(class_1799 stack, class_1657 player,
                                                   class_1309 target, class_1268 hand) {
        if (!canUse(player)) return class_1269.field_5811;
        class_1937 level = player.method_37908();
        if (level.field_9236) {
            if (target instanceof class_1657 targetPlayer) {

                ScreenOpener.openPlayerEditor(targetPlayer);
            } else if (player.method_5715()) {
                ScreenOpener.openRandomizeMob(target);
            } else {
                ScreenOpener.openMobEditor(target);
            }
        }
        return class_1269.method_29236(level.field_9236);
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        if (attacker instanceof class_1657 player && player.method_37908().field_9236) {
            String json = JsonUtil.serializeMobStats(target);
            net.minecraft.class_310.method_1551().field_1774.method_1455(json);
            player.method_43496(class_2561.method_43470("Copied stats to clipboard.")
                    .method_27692(class_124.field_1060));
        }
        return false;
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 ctx,
                                 List<class_2561> lines, class_1836 flag) {
        lines.add(class_2561.method_43470("Right-click block         › edit THIS block").method_27692(class_124.field_1075));
        lines.add(class_2561.method_43470("Shift+right-click block   › edit ALL of that type").method_27692(class_124.field_1080));
        lines.add(class_2561.method_43470("Right-click mob/NPC       › edit mob stats").method_27692(class_124.field_1080));
        lines.add(class_2561.method_43470("Shift+right-click mob     › randomize mob stats").method_27692(class_124.field_1080));
        lines.add(class_2561.method_43470("Right-click player        › edit player stats").method_27692(class_124.field_1080));
        lines.add(class_2561.method_43470("Offhand spawn egg         › edit that mob type").method_27692(class_124.field_1080));
        lines.add(class_2561.method_43470("Right-click (air)         › edit your stats").method_27692(class_124.field_1080));
        lines.add(class_2561.method_43470("Left-click mob            › copy stats JSON").method_27692(class_124.field_1080));

        try {
            net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
            if (mc.field_1687 == null) return;

            if (mc.field_1692 instanceof class_1309 le) {
                class_2960 typeId = class_1299.method_5890(le.method_5864());
                MobStats ms = StatRegistry.getMob(typeId);
                lines.add(class_2561.method_43473());
                if (ms != null) {
                    lines.add(class_2561.method_43470("★ " + typeId.method_12832() + ": custom stats active")
                            .method_27692(class_124.field_1054));
                    lines.add(class_2561.method_43470("  HP " + ms.maxHealth + "  Dmg " + ms.attackDamage)
                            .method_27692(class_124.field_1068));
                } else {
                    lines.add(class_2561.method_43470("Looking at: " + typeId.method_12832())
                            .method_27692(class_124.field_1063));
                }
            } else if (mc.field_1765 instanceof class_3965 bhr) {
                net.minecraft.class_2338 bhp = bhr.method_17777();
                class_2248 block = mc.field_1687.method_8320(bhp).method_26204();
                class_2960 blockId = class_7923.field_41175.method_10221(block);

                String posKey = StatRegistry.makePosKey(mc.field_1687.method_27983(), bhp);
                BlockStats bsPos  = StatRegistry.getBlockAt(posKey);
                BlockStats bsType = StatRegistry.getBlock(blockId);
                if (bsPos != null) {
                    lines.add(class_2561.method_43473());
                    lines.add(class_2561.method_43470("★ THIS block: custom stats active")
                            .method_27692(class_124.field_1075));
                    lines.add(class_2561.method_43470("  Hardness " + bsPos.hardness + "  Light " + bsPos.lightEmission
                            + "  Slip " + bsPos.slipperiness).method_27692(class_124.field_1068));
                    if (bsType != null)
                        lines.add(class_2561.method_43470("  (type override also active)")
                                .method_27692(class_124.field_1063));
                } else if (bsType != null) {
                    lines.add(class_2561.method_43473());
                    lines.add(class_2561.method_43470("★ " + blockId.method_12832() + ": type stats active")
                            .method_27692(class_124.field_1054));
                    lines.add(class_2561.method_43470("  Hardness " + bsType.hardness + "  Light " + bsType.lightEmission)
                            .method_27692(class_124.field_1068));
                }
            }
        } catch (Exception ignored) {}
    }

    private boolean canUse(class_1657 player) {
        CraftStatsConfig.ConfigData cfg = CraftStatsConfig.get();
        if (cfg.requireOp && player instanceof class_3222 sp) {
            return sp.method_5687(2);
        }
        if (player.method_7337()) return true;
        return cfg.allowSurvival;
    }

    private static String spawnEggEntityTypeId(class_1799 egg) {
        class_2960 itemKey = class_7923.field_41178.method_10221(egg.method_7909());
        String path = itemKey.method_12832();
        if (path.endsWith("_spawn_egg")) {
            String entityPath = path.substring(0, path.length() - "_spawn_egg".length());
            class_2960 entityKey = class_2960.method_60655(
                    itemKey.method_12836(), entityPath);
            if (class_7923.field_41177.method_10250(entityKey)) {
                return entityKey.toString();
            }
        }
        return null;
    }
}
