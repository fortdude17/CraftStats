package com.craftstats.common.gui;

import com.craftstats.common.stats.BlockStats;
import com.craftstats.common.util.BlockStatExtractor;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7923;

public class BlockSourceBrowserScreen extends class_437 {

    private static final int LIST_W    = 200;
    private static final int PREVIEW_W = 220;
    private static final int ROW_H     = 20;
    private static final int PAD       = 6;
    private static final int SEARCH_H  = 20;
    private static final int FOOTER_H  = 28;

    private final class_437         parent;
    private final Consumer<BlockStats> onApply;

    private final List<class_2248> allBlocks   = new ArrayList<>();
    private final List<class_2248> filtered    = new ArrayList<>();

    private class_2248     selected;
    private BlockStats preview;
    private int       scrollOffset = 0;
    private int       hoveredIndex = -1;

    private class_342 searchBox;
    private class_4185  applyBtn;
    private class_4185  cancelBtn;

    public BlockSourceBrowserScreen(class_437 parent, Consumer<BlockStats> onApply) {
        super(class_2561.method_43470("Block Preset Browser"));
        this.parent  = parent;
        this.onApply = onApply;
    }

    @Override
    protected void method_25426() {

        allBlocks.clear();
        for (class_2248 b : class_7923.field_41175) {
            if (b == class_2246.field_10124 || b.method_8389() == class_1802.field_8162) continue;
            allBlocks.add(b);
        }
        allBlocks.sort(Comparator.comparing(b -> class_7923.field_41175.method_10221(b).toString()));

        filtered.clear();
        filtered.addAll(allBlocks);

        int listX    = PAD;
        int listY    = PAD + SEARCH_H + 4;
        int footerY  = this.field_22790 - FOOTER_H - PAD;

        searchBox = new class_342(field_22793, listX, PAD, LIST_W, SEARCH_H, class_2561.method_43470("Search..."));
        searchBox.method_1880(64);
        searchBox.method_47404(class_2561.method_43470("Search blocks...").method_27692(
                net.minecraft.class_124.field_1063));
        searchBox.method_1863(this::onSearch);
        method_37063(searchBox);

        int bw = 120, bh = 18;
        int totalBW = bw * 2 + PAD;
        int bx = (this.field_22789 - totalBW) / 2;
        int by = footerY + (FOOTER_H - bh) / 2;

        applyBtn  = class_4185.method_46430(class_2561.method_43470("Apply These Stats"), b -> doApply())
                .method_46434(bx, by, bw, bh).method_46431();
        cancelBtn = class_4185.method_46430(class_2561.method_43470("Cancel"), b -> method_25419())
                .method_46434(bx + bw + PAD, by, bw, bh).method_46431();
        method_37063(applyBtn);
        method_37063(cancelBtn);

        if (!filtered.isEmpty()) selectBlock(filtered.get(0));
    }

    private void onSearch(String query) {
        filtered.clear();
        String q = query.toLowerCase().trim();
        for (class_2248 b : allBlocks) {
            String id = class_7923.field_41175.method_10221(b).toString();
            if (q.isEmpty() || id.contains(q)) filtered.add(b);
        }
        scrollOffset = 0;
        if (!filtered.isEmpty()) selectBlock(filtered.get(0));
        else { selected = null; preview = null; }
    }

    private void selectBlock(class_2248 b) {
        selected = b;
        preview  = BlockStatExtractor.extractFrom(b);
        applyBtn.field_22763 = true;
    }

    private void doApply() {
        if (preview != null && onApply != null) onApply.accept(preview);
        class_310.method_1551().method_1507(parent);
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(parent);
    }

    @Override
    public void method_25420(class_332 g, int mx, int my, float delta) {}

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        int listX   = PAD;
        int listY   = PAD + SEARCH_H + 4;
        int footerY = this.field_22790 - FOOTER_H - PAD;
        int listH   = footerY - listY - PAD;

        g.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF0D0D1C);

        g.method_25294(listX, listY, listX + LIST_W, listY + listH, 0xFF16213E);
        drawBorder(g, listX, listY, listX + LIST_W, listY + listH, 0xFF3355AA);

        int prevX = listX + LIST_W + PAD * 2;
        int prevW = this.field_22789 - prevX - PAD;
        g.method_25294(prevX, listY, prevX + prevW, listY + listH, 0xFF1A1A2E);
        drawBorder(g, prevX, listY, prevX + prevW, listY + listH, 0xFF3355AA);

        g.method_25294(0, footerY, this.field_22789, footerY + FOOTER_H + PAD, 0xFF0F3460);
        drawBorder(g, 0, footerY, this.field_22789, footerY + FOOTER_H + PAD, 0xFF3355AA);

        g.method_25300(field_22793, "§b§lBlock Preset — copy any block's real stats",
                this.field_22789 / 2, listY - 14, 0xFFFFFFFF);

        g.method_44379(listX, listY, listX + LIST_W, listY + listH);
        hoveredIndex = -1;
        for (int i = 0; i < filtered.size(); i++) {
            int rowY = listY + i * ROW_H - scrollOffset;
            if (rowY + ROW_H < listY || rowY > listY + listH) continue;

            class_2248 b = filtered.get(i);
            boolean sel = b == selected;
            boolean hov = mx >= listX && mx < listX + LIST_W && my >= rowY && my < rowY + ROW_H;
            if (hov) hoveredIndex = i;

            if (sel) g.method_25294(listX, rowY, listX + LIST_W, rowY + ROW_H, 0xFF2244AA);
            else if (hov) g.method_25294(listX, rowY, listX + LIST_W, rowY + ROW_H, 0xFF1A2A50);

            class_1799 icon = new class_1799(b.method_8389());
            g.method_51427(icon, listX + 2, rowY + 2);

            class_2960 id = class_7923.field_41175.method_10221(b);
            String name = id.method_12832().replace('_', ' ');
            if (name.length() > 18) name = name.substring(0, 17) + "…";
            g.method_51433(field_22793, name, listX + 20, rowY + (ROW_H - 8) / 2, sel ? 0xFFFFFFFF : 0xFFCCCCCC, false);
        }
        g.method_44380();

        if (preview != null && selected != null) {
            class_2960 selId = class_7923.field_41175.method_10221(selected);
            int px = prevX + PAD, py = listY + PAD;
            int lineH = 11;

            g.method_51433(field_22793, "§e§l" + selId.method_12832().replace('_', ' '), px, py, 0xFFFFFFFF, false);
            py += lineH + 4;
            g.method_51433(field_22793, "§7" + selId, px, py, 0xFF666666, false);
            py += lineH + 8;

            class_1799 icon = new class_1799(selected.method_8389());
            g.method_51427(icon, prevX + prevW - 32, listY + PAD);
            g.method_51431(field_22793, icon, prevX + prevW - 32, listY + PAD);

            g.method_51433(field_22793, "§aPhysical", px, py, 0xFFFFFFFF, false); py += lineH + 2;
            drawStat(g, px, py, "Hardness",        fmt(preview.hardness));    py += lineH;
            drawStat(g, px, py, "Blast Resist",    fmt(preview.blastResistance)); py += lineH;
            drawStat(g, px, py, "Slipperiness",    fmt(preview.slipperiness)); py += lineH;
            drawStat(g, px, py, "No Collision",    preview.noCollision ? "§aYes" : "§7No"); py += lineH;
            drawStat(g, px, py, "Climbable",       preview.climbable   ? "§aYes" : "§7No"); py += lineH;
            py += 6;

            g.method_51433(field_22793, "§aProperties", px, py, 0xFFFFFFFF, false); py += lineH + 2;
            drawStat(g, px, py, "Light Emission",  String.valueOf(preview.lightEmission)); py += lineH;
            py += 6;

            g.method_51433(field_22793, "§aStep-On Effects", px, py, 0xFFFFFFFF, false); py += lineH + 2;
            drawStat(g, px, py, "Step Damage",  preview.stepDamage  > 0 ? "§c" + fmt(preview.stepDamage) : "§7None"); py += lineH;
            drawStat(g, px, py, "Speed",        preview.speedModifier != 1.0f ? "§e" + fmt(preview.speedModifier) + "×" : "§7Normal"); py += lineH;
            drawStat(g, px, py, "Freeze",       preview.freezeOnStep ? "§bYes" : "§7No"); py += lineH;
            drawStat(g, px, py, "Bounce",       preview.bounceFactor > 0 ? "§d" + fmt(preview.bounceFactor) : "§7No"); py += lineH;
        } else {
            g.method_25300(field_22793, "§7Select a block from the list",
                    prevX + prevW / 2, listY + listH / 2, 0xFFAAAAAA);
        }

        super.method_25394(g, mx, my, delta);
    }

    private void drawStat(class_332 g, int x, int y, String label, String value) {
        g.method_51433(field_22793, "§8" + label + ": §f" + value, x, y, 0xFFFFFFFF, false);
    }

    private static String fmt(float v) {
        if (v == Math.floor(v) && Math.abs(v) < 1e6) return String.valueOf((long)v);
        return String.format("%.3f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    private static void drawBorder(class_332 g, int x1, int y1, int x2, int y2, int color) {
        g.method_25294(x1,     y1,     x2,     y1 + 1, color);
        g.method_25294(x1,     y2 - 1, x2,     y2,     color);
        g.method_25294(x1,     y1,     x1 + 1, y2,     color);
        g.method_25294(x2 - 1, y1,     x2,     y2,     color);
    }

    @Override
    public boolean method_25402(double mx, double my, int btn) {
        if (super.method_25402(mx, my, btn)) return true;

        int listX  = PAD;
        int listY  = PAD + SEARCH_H + 4;
        int footerY= this.field_22790 - FOOTER_H - PAD;
        int listH  = footerY - listY - PAD;

        if (mx >= listX && mx < listX + LIST_W && my >= listY && my < listY + listH) {
            int idx = (int)(my - listY + scrollOffset) / ROW_H;
            if (idx >= 0 && idx < filtered.size()) {
                selectBlock(filtered.get(idx));
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean method_25401(double mx, double my, double hScroll, double vScroll) {
        int footerY = this.field_22790 - FOOTER_H - PAD;
        int listY   = PAD + SEARCH_H + 4;
        int listH   = footerY - listY - PAD;
        int maxScroll = Math.max(0, filtered.size() * ROW_H - listH);
        scrollOffset  = (int) Math.max(0, Math.min(maxScroll, scrollOffset - vScroll * ROW_H));
        return true;
    }

    @Override
    public boolean method_25404(int key, int scan, int mods) {
        if (searchBox.method_25370()) return searchBox.method_25404(key, scan, mods);
        return super.method_25404(key, scan, mods);
    }

    @Override
    public boolean method_25400(char c, int mods) {
        if (searchBox.method_25370()) return searchBox.method_25400(c, mods);
        return super.method_25400(c, mods);
    }

    @Override
    public boolean method_25421() { return false; }
}
