package com.craftstats.common.item;

import com.craftstats.common.CraftStats;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1792;
import net.minecraft.class_7924;

public final class ModItems {

    public static final DeferredRegister<class_1792> ITEMS =
            DeferredRegister.create(CraftStats.MOD_ID, class_7924.field_41197);

    public static final RegistrySupplier<class_1792> CRAFT_WAND =
            ITEMS.register("craft_wand",
                    () -> new CraftWandItem(new class_1792.class_1793().method_7889(1)));

    public static final RegistrySupplier<class_1792> PLAYER_STATS_BOOK =
            ITEMS.register("player_stats_book",
                    () -> new PlayerStatsBookItem(new class_1792.class_1793().method_7889(1)));

    public static void register() {
        ITEMS.register();
    }
}
